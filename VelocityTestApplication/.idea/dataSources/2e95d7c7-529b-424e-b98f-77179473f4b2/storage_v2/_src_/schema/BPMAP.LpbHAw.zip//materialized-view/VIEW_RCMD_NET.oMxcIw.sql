create materialized view VIEW_RCMD_NET
refresh force on demand
  as
    SELECT trim(T.FINA_INST_CODE) AS RCMD_NET_CODE, --推荐方网点代码
  trim(T.FINA_CHN_NAME)  AS RCMD_NET_NAME,  --推荐方网点名称
  trim(T.FINA_CTRL_CODE)  AS RCMD_PARAM_MCHT_CODE,  --推荐方参数设置机构代码
  trim(T.FINA_CTRL_CHN_NAME) AS RCMD_PARAM_MCHT_NAME,  --推荐方参数设置机构名称
  trim(T.FINA_COOP_ORG_CATEGORY)  AS RCMD_MCHT_TYPE,  --推荐机构类型代码
  trim(T.FINA_COOP_ORG_CATEGORY_NAME)  AS RCMD_MCHT_TYPE_NAME,  --推荐机构类型名称
  trim(T.FINA_COAG_CODE)  AS RCMD_MCHT_CODE,  --推荐机构代码
  trim(T.FINA_COAG_CHN_NAME)  AS RCMD_MCHT_NAME,  --推荐机构名称
  trim(T.MEAC_COOP_INST_CODE)  AS STORE_CODE,  --所属网点代码
  trim(T.SRDF_CRE_LINE_CODE)  AS PROD_CODE,  --推荐产品代码
  trim(T.FINA_AREA_CODE)  AS AREA_CODE,  --区域代码
  trim(T.FINA_AREA_NAME) AS AREA_NAME,	--区域名称
  trim(T.FINA_PROVINCE_CODE)  AS PROVINCE_CODE,  --推荐方省份代码
  trim(T.FINA_PROVINCE_NAME) AS PROVINCE_NAME,  --推荐方网点所在省份名称
  trim(T.FINA_CITY_CODE)  AS CITY_CODE,  --推荐方市区代码
  trim(T.FINA_CITY_NAME) AS CITY_NAME,  --推荐方城市名称
  trim(T.FINA_DISTRICT_CODE)  AS DISTRICT_CODE,  --推荐方区县代码
  trim(T.FINA_DISTRICT_NAME) AS DISTRICT_NAME,  --推荐方区县名称
  trim(T.FINA_CHN_ADDR) AS ADDRESS, --地址
  trim(T.FINA_TEL) AS TELPHONE, --网点联系电话
  trim(T.FINA_SETTLE_CODE)  AS RCMD_CLEAR_MCHT_CODE,  --推荐方清算机构编号
  trim(T.FINA_SETTLE_CHN_NAME) AS RCMD_CLEAR_MCHT_NAME, --推荐方清算机构名称
  trim(T.FINA_CUSACQ_FLAG) AS OBTAIN_CUS_FLAG, --推荐点获客权限
  trim(T.FINA_TRIAL_FLAG) AS FIRST_TRIAL_FLAG, --推荐点初审权限
  trim(T.FINA_REMIND_FLAG) AS ASSIST_FLAG, --推荐点协催权限
  trim(T.FINA_STATUS_FLG) AS USE_FLAG
FROM CEVFINARCNT@COMNEWVIEW T
/

