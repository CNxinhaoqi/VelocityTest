create procedure p_kill_inactive_session
as
  cursor t_locked is 
                SELECT l.session_id sid, s.serial# serial, l.locked_mode,l.oracle_username,  
                l.os_user_name,s.machine, o.object_name, s.logon_time ,s.last_call_et 
                FROM v$locked_object l, all_objects o, v$session s  
                WHERE l.object_id = o.object_id  
                AND l.session_id = s.sid and object_type='TABLE' 
                and l.os_user_name='tibco' and s.status='INACTIVE' and s.LAST_CALL_ET>900;
  r_locked t_locked%rowtype;
  cursor t_sessions is
                SELECT distinct l.session_id sid, s.serial# serial
                FROM v$locked_object l, all_objects o, v$session s  
                WHERE l.object_id = o.object_id  
                AND l.session_id = s.sid and object_type='TABLE' 
                and l.os_user_name='tibco' and s.status='INACTIVE' and s.LAST_CALL_ET>900;
  r_sessions t_sessions%rowtype;
  k_sql varchar2(1000);
begin
  open t_locked;
  loop
    fetch t_locked into r_locked;
    exit when t_locked%notfound;
    insert into sys_kill_inactive_session(sid,serial,locked_mode,oracle_username,os_user_name,machine,object_name,logon_time,last_call_et,create_time)
    values (r_locked.sid ,r_locked.serial,r_locked.locked_mode,r_locked.oracle_username,r_locked.os_user_name,r_locked.machine,r_locked.object_name,r_locked.logon_time,r_locked.last_call_et,sysdate);
  end loop;
  close t_locked;
  open t_sessions;
  loop
    fetch t_sessions into r_sessions;
    exit when t_sessions%notfound;
    k_sql := 'alter system kill session ''' || r_sessions.sid || ',' || r_sessions.serial || '''';
    execute immediate k_sql;
  end loop;
  close t_sessions;
end;

/

