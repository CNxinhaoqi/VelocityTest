create materialized view VIEW_RCMD_STORE
refresh force on demand
  as
    SELECT
	DISTINCT
	(case when T1.FINA_INST_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_INST_CODE)) end) AS STORE_CODE,
	(case when T1.FINA_CHN_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_CHN_NAME)) end) AS STORE_NAME,
	(case when T1.FINA_COOP_ORG_CATEGORY = ' ' then null else LTRIM(RTRIM(T1.FINA_COOP_ORG_CATEGORY)) end) AS MCHT_TYPE,
	(case when T1.FINA_COAG_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_COAG_CODE)) end) AS MCHT_CODE,
	(case when T1.FINA_COAG_CHN_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_COAG_CHN_NAME)) end) AS MCHT_NAME,
	(case when T1.FINA_CTRL_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_CTRL_CODE)) end) AS PARAM_ORG_CODE,
	(case when T1.FINA_CTRL_CHN_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_CTRL_CHN_NAME)) end) AS PARAM_ORG_NAME,
	(case when T1.FINA_SETTLE_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_SETTLE_CODE)) end) AS CLEAR_MCHT_CODE,
	(case when T1.FINA_SETTLE_CHN_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_SETTLE_CHN_NAME)) end) AS CLEAR_MCHT_NAME,
	(case when T1.FINA_AREA_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_AREA_CODE)) end) AS AREA_CODE,
	(case when T1.FINA_AREA_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_AREA_NAME)) end) AS AREA_NAME,
	(case when T1.FINA_PROVINCE_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_PROVINCE_CODE)) end) AS PROVINCE_CODE,
	(case when T1.FINA_PROVINCE_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_PROVINCE_NAME)) end) AS PROVINCE_NAME,
	(case when T1.FINA_CITY_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_CITY_CODE)) end) AS CITY_CODE,
	(case when T1.FINA_CITY_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_CITY_NAME)) end) AS CITY_NAME,
	(case when T1.FINA_DISTRICT_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_DISTRICT_CODE)) end) AS DISTRICT_CODE,
	(case when T1.FINA_DISTRICT_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_DISTRICT_NAME)) end) AS DISTRICT_NAME
FROM CEVFINARC@COMNEWVIEW T1
/

