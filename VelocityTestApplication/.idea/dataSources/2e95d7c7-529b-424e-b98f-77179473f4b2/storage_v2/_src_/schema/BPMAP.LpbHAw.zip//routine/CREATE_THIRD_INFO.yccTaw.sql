create procedure create_third_info(
	p_user_name IN varchar2
	, p_id_no IN varchar2
	, p_app_num IN varchar2
	, p_phone_no in varchar2)
is
	v_date varchar2(8 char);
	v_count NUMBER;
begin
	v_date := to_char(sysdate,'yyyymmdd');
  v_count := 0;

	--固话
  SELECT COUNT(1) INTO v_count FROM G_PHONEINFO@THIRDSYSTEM WHERE PHONENO=p_phone_no AND DATA_DATE=v_date;
  IF v_count=0 then
    insert into G_PHONEINFO@THIRDSYSTEM (PHONENO, STATUS, NAMEINPUT, ADDRESSINPUT, AREACODE, QUERYTYPE, QUERYRESULT, CORPTEL, CORPNAME, CORPADDRESS, DATA_DATE, DATA_TIME)
    values (p_phone_no, '0', p_user_name, '中国银行上海分行信息科技部', '上海', '0001', '查询成功_有数据', p_phone_no, '中国银行股份有限公司上海市分行', '桂平路555号43号楼', v_date, '114237');
  END IF; 

  -- 学历
  insert into GP_EDUCATION1@THIRDSYSTEM (CHANNELTYPE, STATUS, USERNAME, IDENTITYCARD, SPECIALITYNAME, GRADUATE, EDUCATIONDEGREE, ENROLDATE, GRADUATETIME, STUDYRESULT, STUDYSTYLE, PHOTONAME, DATA_DATE, DATA_TIME)
  values ('鹏元', '0', p_user_name, p_id_no, '信息管理与信息系统', '上海工程技术大学', '本科', '20020901', '2006', '毕业', '普通', '', v_date, '155328');

  insert into GPEDU1REF@THIRDSYSTEM (APPNO, IDENTITYCARD, DATA_DATE)
  values (p_app_num, p_id_no, v_date);

  -- 学籍
  insert into GP_EDUCATION2@THIRDSYSTEM (CHANNELTYPE, STATUS, COMPSTATUS, USERNAME, IDENTITYCARD, GRADUATE, ENROLDATE, SPECIALITYNAME, DATA_DATE, DATA_TIME)
  values ('鹏元', '0', '', p_user_name, p_id_no, '上海工程技术大学', '20020901', '信息管理与信息系统', v_date, '155328');

  insert into GPEDU2REF@THIRDSYSTEM (APPNO, IDENTITYCARD, DATA_DATE)
  values (p_app_num, p_id_no, v_date);

  -- 人行征信
  insert into xreportref@THIRDSYSTEM (APPNO, REPORTSN)
  values (p_app_num, '2013040300001294490625');
--无人行 2013040300001294490625
--有人行 2013112800001512872662
  --公安
  insert into N_GMSFINFO@THIRDSYSTEM (GMSFHM, XM, RESULT_GMSFHM, RESULT_XM, CYM, XB, MZ, CSRQ, SSSSXQ, JGSSX, CSDSSX, ZZ, PCSMC, FWCS, HYZK, WHCD, ZT, XPNAME, ERRORMESSAGE, ERRORCODE, DATA_DATE, DATA_TIME)
  values (p_id_no, p_user_name, '0', '0', '', '男性', '汉族', '19700422', '广东省广州市番禺区', '浙江省杭州市上城区', '浙江省杭州市上城区', '广东省广州市番禺区洛浦街广州碧桂园美苑三十三幢208房', '洛溪新城派出所', '广东华际友天信息科技有限公司', '已婚', '大学本科（简称“大学”）', '0', '', '', '', v_date, '135509');

  insert into ngmsfref@THIRDSYSTEM (APPNO, GMSFHM, DATA_DATE)
  values (p_app_num, p_id_no, v_date);

  --社保
  insert into sb_grxxinfo@THIRDSYSTEM (CERNO, PAYMONTH, PAYFLAG, DATA_DATE, DATA_TIME)
  values (p_id_no, '201306', '0', v_date, '162405');

  insert into sbgrxxref@THIRDSYSTEM (APPNO, CERNO, DATA_DATE)
  values (p_app_num, p_id_no, v_date);

  --固话
  insert into gphoneref@THIRDSYSTEM (APPNO, PHONENO, DATA_DATE)
  values (p_app_num, p_phone_no, v_date);

end create_third_info;

/

