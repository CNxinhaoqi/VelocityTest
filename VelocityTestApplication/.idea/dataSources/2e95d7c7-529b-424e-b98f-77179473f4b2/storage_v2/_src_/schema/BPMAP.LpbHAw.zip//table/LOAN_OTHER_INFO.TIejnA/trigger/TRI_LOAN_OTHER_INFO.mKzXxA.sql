create trigger TRI_LOAN_OTHER_INFO
  after update
  on LOAN_OTHER_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.IS_YEAR_COM_ENP_OWNER is null and :new.IS_YEAR_COM_ENP_OWNER is not null)
     or (:old.IS_YEAR_COM_ENP_OWNER is not null and :new.IS_YEAR_COM_ENP_OWNER is null)
     or (:old.IS_YEAR_COM_ENP_OWNER <> :new.IS_YEAR_COM_ENP_OWNER) --公司经营满一年的企业主
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_OTHER_INFO'
        ,'IS_YEAR_COM_ENP_OWNER'
        ,:old.IS_YEAR_COM_ENP_OWNER
        ,:new.IS_YEAR_COM_ENP_OWNER
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IS_YEAR_COM_SHAREHOLDER is null and :new.IS_YEAR_COM_SHAREHOLDER is not null)
     or (:old.IS_YEAR_COM_SHAREHOLDER is not null and :new.IS_YEAR_COM_SHAREHOLDER is null)
     or (:old.IS_YEAR_COM_SHAREHOLDER <> :new.IS_YEAR_COM_SHAREHOLDER) --公司经营满一年的股东
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_OTHER_INFO'
        ,'IS_YEAR_COM_SHAREHOLDER'
        ,:old.IS_YEAR_COM_SHAREHOLDER
        ,:new.IS_YEAR_COM_SHAREHOLDER
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IS_YEAR_PAYROLL is null and :new.IS_YEAR_PAYROLL is not null)
     or (:old.IS_YEAR_PAYROLL is not null and :new.IS_YEAR_PAYROLL is null)
     or (:old.IS_YEAR_PAYROLL <> :new.IS_YEAR_PAYROLL) --缴金满一年的工薪人士
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_OTHER_INFO'
        ,'IS_YEAR_PAYROLL'
        ,:old.IS_YEAR_PAYROLL
        ,:new.IS_YEAR_PAYROLL
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.AMOUNT_ALGORITHM is null and :new.AMOUNT_ALGORITHM is not null)
     or (:old.AMOUNT_ALGORITHM is not null and :new.AMOUNT_ALGORITHM is null)
     or (:old.AMOUNT_ALGORITHM <> :new.AMOUNT_ALGORITHM) --额度算法
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_OTHER_INFO'
        ,'AMOUNT_ALGORITHM'
        ,:old.AMOUNT_ALGORITHM
        ,:new.AMOUNT_ALGORITHM
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_OTHER_INFO;
/

