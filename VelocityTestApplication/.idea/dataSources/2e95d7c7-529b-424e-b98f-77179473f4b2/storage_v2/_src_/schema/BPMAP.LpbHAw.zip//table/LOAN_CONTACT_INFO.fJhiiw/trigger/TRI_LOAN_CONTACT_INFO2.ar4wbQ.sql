create trigger TRI_LOAN_CONTACT_INFO2
  after delete
  on LOAN_CONTACT_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF :old.CONTACT_IDNO is not null --联系人身份证号
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_IDNO'
        ,:old.CONTACT_IDNO
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_NAME is not null --联系人姓名
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_NAME'
        ,:old.CONTACT_NAME
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_RELATION is not null --联系人与本人（客户）关系代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_RELATION'
        ,:old.CONTACT_RELATION
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_ADDRESS_PROVINCE_CODE is not null --联系人地址(省)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_PROVINCE_CODE'
        ,:old.CONTACT_ADDRESS_PROVINCE_CODE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_ADDRESS_CITY_CODE is not null --联系人地址(市) 代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_CITY_CODE'
        ,:old.CONTACT_ADDRESS_CITY_CODE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_ADDRESS_AREA_CODE is not null --联系人地址(区县) 代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_AREA_CODE'
        ,:old.CONTACT_ADDRESS_AREA_CODE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_ADDRESS is not null --联系人地址(详细)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS'
        ,:old.CONTACT_ADDRESS
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_ADDRESS_ZIPCODE is not null --联系人地址(邮编)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_ZIPCODE'
        ,:old.CONTACT_ADDRESS_ZIPCODE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_MOBILE is not null --联系人手机号码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_MOBILE'
        ,:old.CONTACT_MOBILE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_TEL_AREACODE is not null --联系人电话(区号)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL_AREACODE'
        ,:old.CONTACT_TEL_AREACODE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_TEL is not null --联系人电话
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL'
        ,:old.CONTACT_TEL
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_TEL_EXT is not null --联系人电话(分机号码)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL_EXT'
        ,:old.CONTACT_TEL_EXT
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_NOTE is not null --联系人备注
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_NOTE'
        ,:old.CONTACT_NOTE
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
	IF :old.CONTACT_COM_NAME is not null --联系人公司名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_COM_NAME'
        ,:old.CONTACT_COM_NAME
        ,:old.CREATE_USER
        ,:old.CREATE_USER_NAME
        ,temp_count
        ,sysdate+1/24/60/60
      );
    END IF;
  END IF;
END TRI_LOAN_CONTACT_INFO2;
/

