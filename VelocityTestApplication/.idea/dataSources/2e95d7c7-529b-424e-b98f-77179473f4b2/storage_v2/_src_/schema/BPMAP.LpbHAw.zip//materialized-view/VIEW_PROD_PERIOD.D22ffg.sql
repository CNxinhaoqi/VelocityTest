create materialized view VIEW_PROD_PERIOD
refresh force on demand
  as
    SELECT TRIM(T1.SCDP_CRE_LINE_CODE) AS PROD_CODE
    ,ltrim(rtrim(T1.SCDP_CRE_LINE_GROUP)) AS PROD_TYPE
    ,ltrim(rtrim(T1.SCDP_INST_CODE)) AS PARAM_ORG_CODE
    ,T1.SCDP_INSTALL_PERIOD AS PERIOD
    ,to_date(ltrim(rtrim(T1.SCDP_OPEN_DATE)),'yyyyMMdd') AS OPEN_DATE
    ,to_date(ltrim(rtrim(T1.SCDP_CLOSE_DATE)),'yyyyMMdd') AS CLOSE_DATE
    ,ltrim(rtrim(T1.SCDP_STATUS_FLG)) AS STATUS_FLAG
    ,ltrim(rtrim(T1.SCDP_REMARK)) AS REMARK
FROM CEVSCDP@COMNEWVIEW T1
/

