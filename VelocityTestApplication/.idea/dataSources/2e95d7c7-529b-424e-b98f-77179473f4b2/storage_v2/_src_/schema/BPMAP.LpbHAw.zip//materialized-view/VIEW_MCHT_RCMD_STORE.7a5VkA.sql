create materialized view VIEW_MCHT_RCMD_STORE
refresh force on demand
  as
    SELECT
  DISTINCT
  ltrim(rtrim(T1.FINA_INST_CODE)) AS STORE_CODE
    , (case when T1.FINA_CHN_NAME =' ' or T1.FINA_CHN_NAME is null  then null else T1.FINA_CHN_NAME end) AS STORE_NAME
  , ltrim(rtrim(T1.FINA_INST_CODE_OLD)) AS OLD_STORE_CODE
    , (case when T1.FINA_COAG_CODE =' ' or T1.FINA_COAG_CODE is null  then '0' else ltrim(rtrim(T1.FINA_COAG_CODE)) end) AS MERCHANT_CODE
    , (case when T1.FINA_COAG_CHN_NAME =' ' or T1.FINA_COAG_CHN_NAME is null  then '0' else ltrim(rtrim(T1.FINA_COAG_CHN_NAME)) end) AS MERCHANT_NAME
  , (case when T1.FINA_COOP_ORG_CATEGORY =' ' then null else ltrim(rtrim(T1.FINA_COOP_ORG_CATEGORY)) end) AS MERCHANT_CATE
    , (case when T1.FINA_CTRL_CODE =' ' or T1.FINA_CTRL_CODE is null  then '0' else ltrim(rtrim(T1.FINA_CTRL_CODE)) end) AS PARAM_ORG_CODE
    , (case when T1.FINA_CTRL_CHN_NAME =' ' or T1.FINA_CTRL_CHN_NAME is null  then '0' else ltrim(rtrim(T1.FINA_CTRL_CHN_NAME)) end) AS PARAM_ORG_NAME
    , (case when T1.FINA_SETTLE_CODE =' ' or T1.FINA_SETTLE_CODE is null  then '0' else ltrim(rtrim(T1.FINA_SETTLE_CODE)) end) AS CLEAR_CODE
    , (case when T1.FINA_SETTLE_CHN_NAME =' ' or T1.FINA_SETTLE_CHN_NAME is null  then '0' else ltrim(rtrim(T1.FINA_SETTLE_CHN_NAME)) end) AS CLEAR_NAME
    , (case when T1.FINA_BOC_AREA_CODE =' ' or T1.FINA_BOC_AREA_CODE is null  then null else ltrim(rtrim(T1.FINA_BOC_AREA_CODE)) end) AS AREA_CENTER_CODE
    , (case when T1.FINA_BOC_AREA_NAME =' ' or T1.FINA_BOC_AREA_NAME is null  then null else ltrim(rtrim(T1.FINA_BOC_AREA_NAME)) end) AS AREA_CENTER_NAME
    , (case when T1.FINA_BOCAREA_CODE =' ' or T1.FINA_BOCAREA_CODE is null  then null else ltrim(rtrim(T1.FINA_BOCAREA_CODE)) end) AS AREA_CENTER_CHNL_CODE
    , (case when T1.FINA_BOCAREA_CHN_NAME =' ' or T1.FINA_BOCAREA_CHN_NAME is null  then null else ltrim(rtrim(T1.FINA_BOCAREA_CHN_NAME)) end) AS AREA_CENTER_CHNL_NAME
    , (case when T1.FINA_AREA_CODE =' ' or T1.FINA_AREA_CODE is null  then null else ltrim(rtrim(T1.FINA_AREA_CODE)) end) AS AREA_CODE
    , (case when T1.FINA_AREA_NAME =' ' or T1.FINA_AREA_NAME is null  then null else ltrim(rtrim(T1.FINA_AREA_NAME)) end) AS AREA_NAME
    , (case when T1.FINA_PROVINCE_CODE =' ' or T1.FINA_PROVINCE_CODE is null  then null else ltrim(rtrim(T1.FINA_PROVINCE_CODE)) end) AS PROVINCE_CODE
    , (case when T1.FINA_PROVINCE_NAME =' ' or T1.FINA_PROVINCE_NAME is null  then null else ltrim(rtrim(T1.FINA_PROVINCE_NAME)) end) AS PROVINCE_NAME
    , (case when T1.FINA_CITY_CODE =' ' or T1.FINA_CITY_CODE is null  then null else ltrim(rtrim(T1.FINA_CITY_CODE)) end) AS CITY_CODE
    , (case when T1.FINA_CITY_NAME =' ' or T1.FINA_CITY_NAME is null  then null else ltrim(rtrim(T1.FINA_CITY_NAME)) end) AS CITY_NAME
    , (case when T1.FINA_DISTRICT_CODE =' ' or T1.FINA_DISTRICT_CODE is null  then null else ltrim(rtrim(T1.FINA_DISTRICT_CODE)) end) AS DISTRICT_CODE
    , (case when T1.FINA_DISTRICT_NAME =' ' or T1.FINA_DISTRICT_NAME is null  then null else ltrim(rtrim(T1.FINA_DISTRICT_NAME)) end) AS DISTRICT_NAME
  , (case when T1.FINA_IS_HIGH_GRADE =' ' or T1.FINA_IS_HIGH_GRADE is null  then null else T1.FINA_IS_HIGH_GRADE end) AS IS_HIGH_GRADE
  , (case when T1.FINA_SCORE is null then 0 else CAST(T1.FINA_SCORE AS NUMBER(6,0)) end) AS STORE_SCORE
  , (case when T1.FINA_REVIEW_TIMEOUT is null then 0 else FINA_REVIEW_TIMEOUT end) AS APPROVE_DEADLINE_MINUTES
    , (case when T1.FINA_PERMISS_RCMD =' ' or T1.FINA_PERMISS_RCMD is null  then null else ltrim(rtrim(T1.FINA_PERMISS_RCMD)) end) AS PERMISS_RCMD
    , (case when T1.FINA_NET_KIND =' ' or T1.FINA_NET_KIND is null  then null else ltrim(rtrim(T1.FINA_NET_KIND)) end) AS NET_KIND
FROM CETFINAMORE@COMNEWVIEW T1
/

