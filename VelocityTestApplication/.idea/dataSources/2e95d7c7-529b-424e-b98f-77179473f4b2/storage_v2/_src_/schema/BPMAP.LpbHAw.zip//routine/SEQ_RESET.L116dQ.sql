create procedure seq_reset(v_seqprefix varchar2) as 
n number(10);
tsql varchar2(100);
CURSOR c_seqname IS select SEQUENCE_NAME from dba_sequences where SEQUENCE_NAME LIKE v_seqprefix||'%';
r_row c_seqname%ROWTYPE;
begin
 FOR r_row IN c_seqname loop
	execute immediate 'select '||r_row.SEQUENCE_NAME||'.nextval from dual' into n;
	n:=-(n-1);
	tsql:='alter sequence '||r_row.SEQUENCE_NAME||' increment by '|| n;
	execute immediate tsql;
	execute immediate 'select '||r_row.SEQUENCE_NAME||'.nextval from dual' into n;
	tsql:='alter sequence '||r_row.SEQUENCE_NAME||' increment by 1';
	execute immediate tsql;
	end loop;
 end seq_reset;

/

