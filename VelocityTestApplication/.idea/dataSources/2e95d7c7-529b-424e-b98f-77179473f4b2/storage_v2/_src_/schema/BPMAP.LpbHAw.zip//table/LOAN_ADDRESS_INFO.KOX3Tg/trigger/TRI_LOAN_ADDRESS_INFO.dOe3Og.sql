create trigger TRI_LOAN_ADDRESS_INFO
  after update of HOUSE_ADDRESS, HOUSE_ADDRESS_ZIPCODE, HOUSE_TEL, HOUSE_TEL_AREACODE, HOUSE_TEL_EXT, HOUSE_TYPE, HOUSE_TYPE_NAME, HOUSE_ADDRESS_PROVINCE_CODE, HOUSE_ADDRESS_CITY_CODE, HOUSE_ADDRESS_AREA_CODE
  on LOAN_ADDRESS_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.HOUSE_TYPE is null and :new.HOUSE_TYPE is not null)
     or (:old.HOUSE_TYPE is not null and :new.HOUSE_TYPE is null)
     or (:old.HOUSE_TYPE <> :new.HOUSE_TYPE) --住宅性质
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_TYPE'
        ,:old.HOUSE_TYPE
        ,:new.HOUSE_TYPE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_TYPE_NAME is null and :new.HOUSE_TYPE_NAME is not null)
     or (:old.HOUSE_TYPE_NAME is not null and :new.HOUSE_TYPE_NAME is null)
     or (:old.HOUSE_TYPE_NAME <> :new.HOUSE_TYPE_NAME)  --住宅性质名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_TYPE_NAME'
        ,:old.HOUSE_TYPE_NAME
        ,:new.HOUSE_TYPE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_ADDRESS_PROVINCE_CODE is null and :new.HOUSE_ADDRESS_PROVINCE_CODE is not null)
     or (:old.HOUSE_ADDRESS_PROVINCE_CODE is not null and :new.HOUSE_ADDRESS_PROVINCE_CODE is null)
     or (:old.HOUSE_ADDRESS_PROVINCE_CODE <> :new.HOUSE_ADDRESS_PROVINCE_CODE)  --住宅地址（省）代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_ADDRESS_PROVINCE_CODE'
        ,:old.HOUSE_ADDRESS_PROVINCE_CODE
        ,:new.HOUSE_ADDRESS_PROVINCE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_ADDRESS_CITY_CODE is null and :new.HOUSE_ADDRESS_CITY_CODE is not null)
     or (:old.HOUSE_ADDRESS_CITY_CODE is not null and :new.HOUSE_ADDRESS_CITY_CODE is null)
     or (:old.HOUSE_ADDRESS_CITY_CODE <> :new.HOUSE_ADDRESS_CITY_CODE)  --住宅地址（市）代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_ADDRESS_CITY_CODE'
        ,:old.HOUSE_ADDRESS_CITY_CODE
        ,:new.HOUSE_ADDRESS_CITY_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_ADDRESS_AREA_CODE is null and :new.HOUSE_ADDRESS_AREA_CODE is not null)
     or (:old.HOUSE_ADDRESS_AREA_CODE is not null and :new.HOUSE_ADDRESS_AREA_CODE is null)
     or (:old.HOUSE_ADDRESS_AREA_CODE <> :new.HOUSE_ADDRESS_AREA_CODE)  --住宅地址（区县）代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_ADDRESS_AREA_CODE'
        ,:old.HOUSE_ADDRESS_AREA_CODE
        ,:new.HOUSE_ADDRESS_AREA_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_ADDRESS is null and :new.HOUSE_ADDRESS is not null)
     or (:old.HOUSE_ADDRESS is not null and :new.HOUSE_ADDRESS is null)
     or (:old.HOUSE_ADDRESS <> :new.HOUSE_ADDRESS)  --住宅地址（详细）
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_ADDRESS'
        ,:old.HOUSE_ADDRESS
        ,:new.HOUSE_ADDRESS
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_ADDRESS_ZIPCODE is null and :new.HOUSE_ADDRESS_ZIPCODE is not null)
     or (:old.HOUSE_ADDRESS_ZIPCODE is not null and :new.HOUSE_ADDRESS_ZIPCODE is null)
     or (:old.HOUSE_ADDRESS_ZIPCODE <> :new.HOUSE_ADDRESS_ZIPCODE) --住宅地址（邮编）
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_ADDRESS_ZIPCODE'
        ,:old.HOUSE_ADDRESS_ZIPCODE
        ,:new.HOUSE_ADDRESS_ZIPCODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_TEL_AREACODE is null and :new.HOUSE_TEL_AREACODE is not null)
     or (:old.HOUSE_TEL_AREACODE is not null and :new.HOUSE_TEL_AREACODE is null)
     or (:old.HOUSE_TEL_AREACODE <> :new.HOUSE_TEL_AREACODE)  --住宅电话（区号）
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_TEL_AREACODE'
        ,:old.HOUSE_TEL_AREACODE
        ,:new.HOUSE_TEL_AREACODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_TEL is null and :new.HOUSE_TEL is not null)
     or (:old.HOUSE_TEL is not null and :new.HOUSE_TEL is null)
     or (:old.HOUSE_TEL <> :new.HOUSE_TEL)  --住宅电话
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_TEL'
        ,:old.HOUSE_TEL
        ,:new.HOUSE_TEL
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_TEL_EXT is null and :new.HOUSE_TEL_EXT is not null)
     or (:old.HOUSE_TEL_EXT is not null and :new.HOUSE_TEL_EXT is null)
     or (:old.HOUSE_TEL_EXT <> :new.HOUSE_TEL_EXT)  --住宅电话（分机号码）
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ADDRESS_INFO'
        ,'HOUSE_TEL_EXT'
        ,:old.HOUSE_TEL_EXT
        ,:new.HOUSE_TEL_EXT
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_ADDRESS_INFO;
/

