create materialized view VIEW_PRODUCT_USE_FEE
refresh force on demand
  as
    SELECT TRIM(T1.SDIT_CRE_LINE_CODE) AS PROD_CODE
    ,ltrim(rtrim(T1.SRIT_CRE_LINE_GROUP)) AS PROD_TYPE
    , (case when T1.FINA_CTRL_CODE =' ' or T1.FINA_CTRL_CODE is null  then '0' else T1.FINA_CTRL_CODE end) AS MERCHANT_CODE
    ,TRIM(T1.SDIT_INSTALL_PERIOD) AS PERIOD
    ,TRIM(T1.SDIT_LEND_FEE_RATE) AS FEE_RATE
    ,(case when T1.SDIT_LEND_FEE_TYPE =' ' then null else ltrim(rtrim(T1.SDIT_LEND_FEE_TYPE)) end) AS FEE_TYPE
    ,(case when T1.SDIT_REMARK =' ' then null else ltrim(rtrim(T1.SDIT_REMARK)) end) AS REMARK
    ,TO_DATE(TRIM(T1.SDIT_OPEN_DATE),'yyyyMMdd') AS OPEN_DATE
FROM CEVSDRIT@COMNEWVIEW T1
/

