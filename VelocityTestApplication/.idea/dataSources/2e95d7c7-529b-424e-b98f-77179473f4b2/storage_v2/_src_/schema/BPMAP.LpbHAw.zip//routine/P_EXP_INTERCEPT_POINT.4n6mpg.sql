create PROCEDURE P_EXP_INTERCEPT_POINT
(
 I_TRADEDATE  IN  DATE,
 O_STATUS     OUT CHAR,
 O_RET_MSG    OUT VARCHAR
)
IS
  V_TIME_1               TIMESTAMP;
  V_TIME_2               TIMESTAMP;
  V_TRADEDATE_1          DATE;
  V_TRADEDATE_2          DATE;
  V_CNT                  INT; 
 BEGIN
  ---初始化参数
  O_STATUS  := '0';
  O_RET_MSG := '执行成功';
  V_TIME_1  := SYSDATE;
  V_TRADEDATE_1 :=I_TRADEDATE;
  V_TRADEDATE_2 :=I_TRADEDATE-3;
  V_CNT     := 0; 
--//STEP1-抽一天的数据 --'031313'-信用金；'441212'-旅游金；'911312'-乐享金
BEGIN
    DELETE FROM A_CF_INTERCEPT T WHERE T.APPLY_DATE = I_TRADEDATE;       COMMIT;

    INSERT INTO A_CF_INTERCEPT
    SELECT     A1.APPLICATION_NUMBER                                           --申请编号 
              ,A1.CUSTOMER_ID                                                  --客户身份证号
              ,A3.GEO_CITY    AS CITY                                          --申请定位城市(V_MAIN ID)
              ,A3.LONGITUDE                                                    --申请定位纬度(V_MAIN ID)
              ,A3.LATITUDE                                                     --申请定位经度(V_MAIN ID)
			--  ,A1.CREATE_TIME  AS   APPLY_DATE                                 --进件日期
			  ,TO_DATE(TO_CHAR(A1.CREATE_TIME,'yyyy-MM-dd'),'yyyy-MM-dd') AS APPLY_DATE
              ,A1.PROD_CODE   AS    PROD_ID                                    --产品编号
              ,A2.PROD_NAME    AS   PROD_NM                                    --产品名称
    FROM      (
	          SELECT APPLICATION_NUMBER ,CUSTOMER_ID,CREATE_TIME,PROD_CODE from LOAN_APPLICATION
             WHERE PROD_CODE IN ('031313','441212','911312') AND TO_CHAR(CREATE_TIME,'yyyy-MM-dd')=TO_CHAR(I_TRADEDATE,'yyyy-MM-dd') )   A1
    LEFT JOIN VIEW_PRODUCT   A2
    ON        A1.PROD_CODE = A2.PROD_CODE
    LEFT JOIN LOAN_NETWORK_ADDITION A3
	ON        A3.APPLICATION_NUMBER = A1.APPLICATION_NUMBER
	LEFT JOIN (
	    SELECT B1.*
              FROM (
                  SELECT T.APPLICATION_NUMBER
                         ,ROW_NUMBER() OVER(PARTITION BY T.CUSTOMER_ID,T.PROD_CODE ORDER BY T.APPLICATION_NUMBER) AS RN
                  FROM LOAN_APPLICATION T WHERE PROD_CODE IN ('031313','441212','911312') AND TO_CHAR(CREATE_TIME,'yyyy-MM-dd')=TO_CHAR(I_TRADEDATE,'yyyy-MM-dd')
              ) B1 
              WHERE B1.RN=1
	) A4 ON A1.APPLICATION_NUMBER=A4.APPLICATION_NUMBER
    WHERE   A4.APPLICATION_NUMBER IS NOT NULL   
    AND A3.GEO_CITY IS NOT NULL AND A3.LONGITUDE IS NOT NULL AND A3.LATITUDE IS NOT NULL --定位城市抓到
	;
    COMMIT;

    EXCEPTION
          WHEN OTHERS THEN
             O_RET_MSG := 'INSERT INTO A_CF_INTERCEPT 失败';
          RAISE;
END;

--//STEP2-取每个城市每天进件数
BEGIN
    UPDATE A_CF_INTERCEPT_0 A SET A.APPLY_DATE = I_TRADEDATE;                 COMMIT;--配置表1
    DELETE FROM A_CF_INTERCEPT_CT
	T WHERE T.APPLY_DATE = I_TRADEDATE;           COMMIT;--配置表2

    INSERT INTO A_CF_INTERCEPT_CT
    SELECT NVL(TRIM(A.CITY), B.CITY) APPLY_CITY
        ,NVL(A.APPLY_DATE, B.APPLY_DATE) APPLY_DATE
        ,SUM(NVL(A.UER_CT,0)) APPLY_CT
        ,ROW_NUMBER() OVER(PARTITION BY NVL(A.APPLY_DATE,B.APPLY_DATE) ORDER BY SUM(NVL(A.UER_CT,0))) RN
        ,NVL(A.PROD_ID, B.PROD_ID)
        ,NVL(A.PROD_NM, B.PROD_NM)
        FROM
        (SELECT T.CITY,
                T.PROD_ID,
                T.PROD_NM,
                T.APPLY_DATE,
                COUNT(T.APPLICATION_NUMBER) UER_CT
                FROM A_CF_INTERCEPT    T
				WHERE TO_CHAR(APPLY_DATE,'yyyy-MM-dd')=TO_CHAR(sysdate-8,'yyyy-MM-dd')
                GROUP BY T.APPLY_DATE,T.CITY,T.PROD_ID,T.PROD_NM
                )A
                FULL JOIN A_CF_INTERCEPT_0   B
                ON        A.CITY = B.CITY
                AND       A.APPLY_DATE = B.APPLY_DATE
                AND       A.PROD_ID = B.PROD_ID
      --   WHERE A.APPLY_DATE = I_TRADEDATE
	  WHERE TO_CHAR(A.APPLY_DATE,'yyyy-MM-dd')=TO_CHAR(sysdate-8,'yyyy-MM-dd')
         GROUP BY NVL(TRIM(A.CITY), B.CITY)
               ,NVL(A.APPLY_DATE, B.APPLY_DATE)
               ,NVL(A.PROD_ID, B.PROD_ID)
               ,NVL(A.PROD_NM, B.PROD_NM)
    ;

    COMMIT;

    EXCEPTION
          WHEN OTHERS THEN
             O_RET_MSG := 'INSERT INTO A_CF_INTERCEPT_CT 失败';
          RAISE;
END;

 END P_EXP_INTERCEPT_POINT;
/

