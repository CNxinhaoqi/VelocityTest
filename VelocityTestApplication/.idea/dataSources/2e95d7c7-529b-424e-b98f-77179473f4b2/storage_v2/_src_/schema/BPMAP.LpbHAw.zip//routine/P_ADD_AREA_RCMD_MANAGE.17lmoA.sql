create PROCEDURE P_ADD_AREA_RCMD_MANAGE (
	p_area_center_code VARCHAR2,  --区域中心代码
	p_open_flag NUMBER,--是否开通推荐(1:开通 0:未开通)
	p_rcmd_count_flag NUMBER,--是否限制次数(1:有限制 0:无限制)
	p_rcmd_count NUMBER --限制次数(无限制为99)
) AS
BEGIN
	-- backup old data to history table
	INSERT INTO AREA_RCMD_MANAGE_HISTORY(
		AREA_CENTER_CODE,
		OPEN_FLAG,
		RCMD_COUNT_FLAG,
		RCMD_COUNT,
		RCMD_COUNT_USED,
	    CREATE_TIME,
	    UPDATE_USER,
	    UPDATE_USER_NAME,
	    UPDATE_TIME,
	    REMOVE_TIME)
  SELECT
    AREA_CENTER_CODE,
    OPEN_FLAG,
    RCMD_COUNT_FLAG,
    RCMD_COUNT,
    RCMD_COUNT_USED,
    CREATE_TIME,
    UPDATE_USER,
    UPDATE_USER_NAME,
    UPDATE_TIME,
    SYSDATE
  FROM AREA_RCMD_MANAGE
  WHERE AREA_CENTER_CODE=p_area_center_code;

  -- delete old data
  DELETE FROM AREA_RCMD_MANAGE
  WHERE AREA_CENTER_CODE=p_area_center_code;

    --insert into new data
  INSERT INTO AREA_RCMD_MANAGE(
	AREA_CENTER_CODE,
	OPEN_FLAG,
	RCMD_COUNT_FLAG,
	RCMD_COUNT,
    CREATE_TIME,
    UPDATE_USER,
    UPDATE_USER_NAME,
    UPDATE_TIME)
  VALUES(
    p_area_center_code,
    p_open_flag,
    p_rcmd_count_flag,
    p_rcmd_count,
    SYSDATE,
    'system',
    'system',
    SYSDATE);
  COMMIT;
END;
/

