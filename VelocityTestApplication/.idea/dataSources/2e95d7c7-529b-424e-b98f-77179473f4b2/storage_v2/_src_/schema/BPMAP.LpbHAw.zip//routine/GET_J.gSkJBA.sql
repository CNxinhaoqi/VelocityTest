create FUNCTION GET_J 
(
  D IN NUMBER 
, I IN NUMBER 
) RETURN NUMBER AS 
v_result number(8);
BEGIN

  v_result := D*0.7+I*2*0.3;

  if 2800 >= v_result then 
    return v_result * 0.4;
  elsif v_result <= 3600 then 
    return v_result * 0.5; 
  elsif 3600 < v_result then
    return 3600 * 0.5 + (v_result - 3600) * 0.4; 
  else 
   return 0;
  END IF;
     
END GET_J;

/

