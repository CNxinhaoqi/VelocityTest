create materialized view VIEW_PARAM_ORG
refresh force on demand
  as
    SELECT (case when T1.FINA_INST_CODE =' ' or T1.FINA_INST_CODE is null then '0' else ltrim(rtrim(T1.FINA_INST_CODE)) end) AS PARAM_ORG_CODE --参数设置机构代码 
	,T1.FINA_CHN_NAME AS PARAM_ORG_NAME --参数设置机构名称
	,(case when T1.FINA_COAG_CODE =' ' then null else ltrim(rtrim(T1.FINA_COAG_CODE)) end) AS BELONG_MERCHANT_CODE --所属合作机构代码
	,(case when T1.FINA_COAG_CHN_NAME =' ' then null else ltrim(rtrim(T1.FINA_COAG_CHN_NAME)) end) AS BELONG_MERCHANT_NAME --所属合作机构名称
	,(case when T1.FINA_COOP_ORG_CATEGORY =' ' then null else ltrim(rtrim(T1.FINA_COOP_ORG_CATEGORY)) end) AS BELONG_MERCHANT_CATE --所属合作机构类型
	,(case when T1.FINA_AREA_CODE =' ' then null else ltrim(rtrim(T1.FINA_AREA_CODE)) end) AS AREA_CODE --区域中心代码
	,(case when T1.FINA_AREA_NAME =' ' then null else ltrim(rtrim(T1.FINA_AREA_NAME)) end) AS AREA_NAME --区域中心代码
	,(case when T1.FINA_BOC_AREA_CODE =' ' then null else ltrim(rtrim(T1.FINA_BOC_AREA_CODE)) end) AS AREA_CENTER_CODE --区域中心代码
	,(case when T1.FINA_BOC_AREA_NAME =' ' then null else ltrim(rtrim(T1.FINA_BOC_AREA_NAME)) end) AS AREA_CENTER_NAME --区域中心名称
	,(case when T1.FINA_PROVINCE_CODE =' ' then null else ltrim(rtrim(T1.FINA_PROVINCE_CODE)) end) AS PROVINCE_CODE --省代码
	,(case when T1.FINA_PROVINCE_NAME =' ' then null else ltrim(rtrim(T1.FINA_PROVINCE_NAME)) end) AS PROVINCE_NAME --省名称
	,(case when T1.FINA_CITY_CODE =' ' then null else ltrim(rtrim(T1.FINA_CITY_CODE)) end) AS CITY_CODE --市区代码
	,(case when T1.FINA_CITY_NAME =' ' then null else ltrim(rtrim(T1.FINA_CITY_NAME)) end) AS CITY_NAME --市区名称
	,(case when T1.FINA_DISTRICT_CODE =' ' then null else ltrim(rtrim(T1.FINA_DISTRICT_CODE)) end) AS DISTRICT_CODE --区县代码
	,(case when T1.FINA_DISTRICT_NAME =' ' then null else ltrim(rtrim(T1.FINA_DISTRICT_NAME)) end) AS DISTRICT_NAME --区县名称
FROM CEVFINACTRL@COMNEWVIEW T1
/

