create trigger TRI_LOAN_APPLICATION
  after update
  on LOAN_APPLICATION
  for each row
  when ((old.PROC_CODE = 'GIMGUPCHK' or old.PROC_CODE = 'GRISKOFF') and
        (old.LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or old.LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and
        old.LAST_SPECIAL_PROC_TYPE = 11)
  DECLARE
	temp_count NUMBER(10, 0);
BEGIN
  temp_count := 0;
	IF (:old.RCMD_MCHT_TYPE is null and :new.RCMD_MCHT_TYPE is not null)
     or (:old.RCMD_MCHT_TYPE is not null and :new.RCMD_MCHT_TYPE is null)
     or (:old.RCMD_MCHT_TYPE <> :new.RCMD_MCHT_TYPE) --推荐机构类型
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_MCHT_TYPE'
      ,:old.RCMD_MCHT_TYPE
      ,:new.RCMD_MCHT_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_MCHT_CODE is null and :new.RCMD_MCHT_CODE is not null)
     or (:old.RCMD_MCHT_CODE is not null and :new.RCMD_MCHT_CODE is null)
     or (:old.RCMD_MCHT_CODE <> :new.RCMD_MCHT_CODE) --推荐机构编号
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_MCHT_CODE'
      ,:old.RCMD_MCHT_CODE
      ,:new.RCMD_MCHT_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_CLEAR_CODE is null and :new.RCMD_CLEAR_CODE is not null)
     or (:old.RCMD_CLEAR_CODE is not null and :new.RCMD_CLEAR_CODE is null)
     or (:old.RCMD_CLEAR_CODE <> :new.RCMD_CLEAR_CODE) --推荐方清算机构编号
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_CLEAR_CODE'
      ,:old.RCMD_CLEAR_CODE
      ,:new.RCMD_CLEAR_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_STORE_CODE is null and :new.RCMD_STORE_CODE is not null)
     or (:old.RCMD_STORE_CODE is not null and :new.RCMD_STORE_CODE is null)
     or (:old.RCMD_STORE_CODE <> :new.RCMD_STORE_CODE) --推荐方(网点)编号
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_STORE_CODE'
      ,:old.RCMD_STORE_CODE
      ,:new.RCMD_STORE_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_AREA_CODE is null and :new.RCMD_AREA_CODE is not null)
     or (:old.RCMD_AREA_CODE is not null and :new.RCMD_AREA_CODE is null)
     or (:old.RCMD_AREA_CODE <> :new.RCMD_AREA_CODE) --推荐方区域代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_AREA_CODE'
      ,:old.RCMD_AREA_CODE
      ,:new.RCMD_AREA_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_PROVINCE_CODE is null and :new.RCMD_PROVINCE_CODE is not null)
     or (:old.RCMD_PROVINCE_CODE is not null and :new.RCMD_PROVINCE_CODE is null)
     or (:old.RCMD_PROVINCE_CODE <> :new.RCMD_PROVINCE_CODE) --推荐方省代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_PROVINCE_CODE'
      ,:old.RCMD_PROVINCE_CODE
      ,:new.RCMD_PROVINCE_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_CITY_CODE is null and :new.RCMD_CITY_CODE is not null)
     or (:old.RCMD_CITY_CODE is not null and :new.RCMD_CITY_CODE is null)
     or (:old.RCMD_CITY_CODE <> :new.RCMD_CITY_CODE) --推荐方市代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_CITY_CODE'
      ,:old.RCMD_CITY_CODE
      ,:new.RCMD_CITY_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_DISTRICT_CODE is null and :new.RCMD_DISTRICT_CODE is not null)
     or (:old.RCMD_DISTRICT_CODE is not null and :new.RCMD_DISTRICT_CODE is null)
     or (:old.RCMD_DISTRICT_CODE <> :new.RCMD_DISTRICT_CODE) --推荐方区县代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_DISTRICT_CODE'
      ,:old.RCMD_DISTRICT_CODE
      ,:new.RCMD_DISTRICT_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_USER_ID is null and :new.RCMD_USER_ID is not null)
     or (:old.RCMD_USER_ID is not null and :new.RCMD_USER_ID is null)
     or (:old.RCMD_USER_ID <> :new.RCMD_USER_ID) --推荐员工工号
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_USER_ID'
      ,:old.RCMD_USER_ID
      ,:new.RCMD_USER_ID
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_USER_CONTACT is null and :new.RCMD_USER_CONTACT is not null)
     or (:old.RCMD_USER_CONTACT is not null and :new.RCMD_USER_CONTACT is null)
     or (:old.RCMD_USER_CONTACT <> :new.RCMD_USER_CONTACT) --推荐员工联系方式 
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_USER_CONTACT'
      ,:old.RCMD_USER_CONTACT
      ,:new.RCMD_USER_CONTACT
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.CUSTOMER_CATEGORY_CODE is null and :new.CUSTOMER_CATEGORY_CODE is not null)
     or (:old.CUSTOMER_CATEGORY_CODE is not null and :new.CUSTOMER_CATEGORY_CODE is null)
     or (:old.CUSTOMER_CATEGORY_CODE <> :new.CUSTOMER_CATEGORY_CODE) --客群分类
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'CUSTOMER_CATEGORY_CODE'
      ,:old.CUSTOMER_CATEGORY_CODE
      ,:new.CUSTOMER_CATEGORY_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.CUSTOMER_GROUP_CODE is null and :new.CUSTOMER_GROUP_CODE is not null)
     or (:old.CUSTOMER_GROUP_CODE is not null and :new.CUSTOMER_GROUP_CODE is null)
     or (:old.CUSTOMER_GROUP_CODE <> :new.CUSTOMER_GROUP_CODE) --客群代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'CUSTOMER_GROUP_CODE'
      ,:old.CUSTOMER_GROUP_CODE
      ,:new.CUSTOMER_GROUP_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.CUSTOMER_GROUP_CODE2 is null and :new.CUSTOMER_GROUP_CODE2 is not null)
     or (:old.CUSTOMER_GROUP_CODE2 is not null and :new.CUSTOMER_GROUP_CODE2 is null)
     or (:old.CUSTOMER_GROUP_CODE2 <> :new.CUSTOMER_GROUP_CODE2) --客群代码二
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'CUSTOMER_GROUP_CODE2'
      ,:old.CUSTOMER_GROUP_CODE2
      ,:new.CUSTOMER_GROUP_CODE2
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.CUSTOMER_GROUP_CODE3 is null and :new.CUSTOMER_GROUP_CODE3 is not null)
     or (:old.CUSTOMER_GROUP_CODE3 is not null and :new.CUSTOMER_GROUP_CODE3 is null)
     or (:old.CUSTOMER_GROUP_CODE3 <> :new.CUSTOMER_GROUP_CODE3) --客群代码三
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'CUSTOMER_GROUP_CODE3'
      ,:old.CUSTOMER_GROUP_CODE3
      ,:new.CUSTOMER_GROUP_CODE3
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.HIRE_TYPE_CODE is null and :new.HIRE_TYPE_CODE is not null)
     or (:old.HIRE_TYPE_CODE is not null and :new.HIRE_TYPE_CODE is null)
     or (:old.HIRE_TYPE_CODE <> :new.HIRE_TYPE_CODE) --雇用类型代码
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'HIRE_TYPE_CODE'
      ,:old.HIRE_TYPE_CODE
      ,:new.HIRE_TYPE_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.LOAN_AMOUNT is null and :new.LOAN_AMOUNT is not null)
     or (:old.LOAN_AMOUNT is not null and :new.LOAN_AMOUNT is null)
     or (:old.LOAN_AMOUNT <> :new.LOAN_AMOUNT) --贷款申请额度
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'LOAN_AMOUNT'
      ,:old.LOAN_AMOUNT
      ,:new.LOAN_AMOUNT
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.LOAN_PERIODS is null and :new.LOAN_PERIODS is not null)
     or (:old.LOAN_PERIODS is not null and :new.LOAN_PERIODS is null)
     or (:old.LOAN_PERIODS <> :new.LOAN_PERIODS) --贷款期数
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'LOAN_PERIODS'
      ,:old.LOAN_PERIODS
      ,:new.LOAN_PERIODS
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.REPAY_TYPE_ID is null and :new.REPAY_TYPE_ID is not null)
     or (:old.REPAY_TYPE_ID is not null and :new.REPAY_TYPE_ID is null)
     or (:old.REPAY_TYPE_ID <> :new.REPAY_TYPE_ID) --还款方式
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'REPAY_TYPE_ID'
      ,:old.REPAY_TYPE_ID
      ,:new.REPAY_TYPE_ID
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.REPAY_DATE is null and :new.REPAY_DATE is not null)
     or (:old.REPAY_DATE is not null and :new.REPAY_DATE is null)
     or (:old.REPAY_DATE <> :new.REPAY_DATE) --还款日期
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'REPAY_DATE'
      ,:old.REPAY_DATE
      ,:new.REPAY_DATE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.LOAN_PURPOSE_CODE is null and :new.LOAN_PURPOSE_CODE is not null)
     or (:old.LOAN_PURPOSE_CODE is not null and :new.LOAN_PURPOSE_CODE is null)
     or (:old.LOAN_PURPOSE_CODE <> :new.LOAN_PURPOSE_CODE) --贷款用途
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'LOAN_PURPOSE_CODE'
      ,:old.LOAN_PURPOSE_CODE
      ,:new.LOAN_PURPOSE_CODE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.LOAN_PURPOSE_DESC is null and :new.LOAN_PURPOSE_DESC is not null)
     or (:old.LOAN_PURPOSE_DESC is not null and :new.LOAN_PURPOSE_DESC is null)
     or (:old.LOAN_PURPOSE_DESC <> :new.LOAN_PURPOSE_DESC) --贷款用途说明
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'LOAN_PURPOSE_DESC'
      ,:old.LOAN_PURPOSE_DESC
      ,:new.LOAN_PURPOSE_DESC
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.DEBITCUSTOMER_ID is null and :new.DEBITCUSTOMER_ID is not null)
     or (:old.DEBITCUSTOMER_ID is not null and :new.DEBITCUSTOMER_ID is null)
     or (:old.DEBITCUSTOMER_ID <> :new.DEBITCUSTOMER_ID) --借记卡卡号
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'DEBITCUSTOMER_ID'
      ,:old.DEBITCUSTOMER_ID
      ,:new.DEBITCUSTOMER_ID
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.FEE_KIND is null and :new.FEE_KIND is not null)
     or (:old.FEE_KIND is not null and :new.FEE_KIND is null)
     or (:old.FEE_KIND <> :new.FEE_KIND) --利费率方式
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'FEE_KIND'
      ,:old.FEE_KIND
      ,:new.FEE_KIND
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.INSTAL_TYPE is null and :new.INSTAL_TYPE is not null)
     or (:old.INSTAL_TYPE is not null and :new.INSTAL_TYPE is null)
     or (:old.INSTAL_TYPE <> :new.INSTAL_TYPE) --分期方案
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'INSTAL_TYPE'
      ,:old.INSTAL_TYPE
      ,:new.INSTAL_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.INTREST_TYPE is null and :new.INTREST_TYPE is not null)
     or (:old.INTREST_TYPE is not null and :new.INTREST_TYPE is null)
     or (:old.INTREST_TYPE <> :new.INTREST_TYPE) --分期利率方案
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'INTREST_TYPE'
      ,:old.INTREST_TYPE
      ,:new.INTREST_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.INSTAL_FEE_TYPE is null and :new.INSTAL_FEE_TYPE is not null)
     or (:old.INSTAL_FEE_TYPE is not null and :new.INSTAL_FEE_TYPE is null)
     or (:old.INSTAL_FEE_TYPE <> :new.INSTAL_FEE_TYPE) --分期手续费方案 
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'INSTAL_FEE_TYPE'
      ,:old.INSTAL_FEE_TYPE
      ,:new.INSTAL_FEE_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.PRE_REPAYMENT_TYPE is null and :new.PRE_REPAYMENT_TYPE is not null)
     or (:old.PRE_REPAYMENT_TYPE is not null and :new.PRE_REPAYMENT_TYPE is null)
     or (:old.PRE_REPAYMENT_TYPE <> :new.PRE_REPAYMENT_TYPE) --分期手续费/提前还款手续费收取方式
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'PRE_REPAYMENT_TYPE'
      ,:old.PRE_REPAYMENT_TYPE
      ,:new.PRE_REPAYMENT_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.EASY_PAY_TYPE is null and :new.EASY_PAY_TYPE is not null)
     or (:old.EASY_PAY_TYPE is not null and :new.EASY_PAY_TYPE is null)
     or (:old.EASY_PAY_TYPE <> :new.EASY_PAY_TYPE) --輕鬆還方案
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'EASY_PAY_TYPE'
      ,:old.EASY_PAY_TYPE
      ,:new.EASY_PAY_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.FIRST_PAYMENT_TYPE is null and :new.FIRST_PAYMENT_TYPE is not null)
     or (:old.FIRST_PAYMENT_TYPE is not null and :new.FIRST_PAYMENT_TYPE is null)
     or (:old.FIRST_PAYMENT_TYPE <> :new.FIRST_PAYMENT_TYPE) --首付款方案
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'FIRST_PAYMENT_TYPE'
      ,:old.FIRST_PAYMENT_TYPE
      ,:new.FIRST_PAYMENT_TYPE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.LIMIT_DEADLINE is null and :new.LIMIT_DEADLINE is not null)
     or (:old.LIMIT_DEADLINE is not null and :new.LIMIT_DEADLINE is null)
     or (:old.LIMIT_DEADLINE <> :new.LIMIT_DEADLINE) --宽缓期
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'LIMIT_DEADLINE'
      ,:old.LIMIT_DEADLINE
      ,:new.LIMIT_DEADLINE
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
  IF (:old.RCMD_USER_NAME is null and :new.RCMD_USER_NAME is not null)
     or (:old.RCMD_USER_NAME is not null and :new.RCMD_USER_NAME is null)
     or (:old.RCMD_USER_NAME <> :new.RCMD_USER_NAME) --推荐人姓名
  THEN
    temp_count := temp_count + 1;
    Insert into DATA_UPDATE_RECORD 
    (
      APPLICATION_NUMBER,
      PROC_CODE,
      TABLE_NAME,
      COLUMN_NAME,
      BEFORE_VALUE,
      AFTER_VALUE,
      USER_CODE,
      USER_NAME,
      SEQ_NUM,
      CREATE_TIME
    ) 
    values (
      :old.APPLICATION_NUMBER
      ,:new.PROC_CODE
      ,'LOAN_APPLICATION'
      ,'RCMD_USER_NAME'
      ,:old.RCMD_USER_NAME
      ,:new.RCMD_USER_NAME
      ,:new.UPDATE_USER
      ,:new.UPDATE_USER_NAME
      ,temp_count
      ,sysdate
    );
  END IF;
END TRI_LOAN_APPLICATION;
/

