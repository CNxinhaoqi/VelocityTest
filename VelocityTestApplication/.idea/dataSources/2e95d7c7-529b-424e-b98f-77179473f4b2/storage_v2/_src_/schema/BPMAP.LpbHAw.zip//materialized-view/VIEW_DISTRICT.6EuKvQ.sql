create materialized view VIEW_DISTRICT
refresh force on demand
  as
    SELECT ltrim(rtrim(DIST_COM_CODE)) AS DISTRICT_CODE
	,ltrim(rtrim(DIST_CHN_NAME)) AS DISTRICT_NAME
	,ltrim(rtrim(DIST_UPPER_CODE)) AS CITY_CODE
FROM CEVDIST@COMNEWVIEW
WHERE DIST_TYPE = 4
/

