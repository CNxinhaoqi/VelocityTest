create materialized view VIEW_PROD_MERCHANT
refresh force on demand
  as
    SELECT TRIM(T1.SCDF_CRE_LINE_CODE) AS PROD_CODE
    ,ltrim(rtrim(T1.SDF_CREDIT_CHINESE)) AS PROD_NAME
    , (case when T1.SDF_CREDIT_TYPE = ' ' then null else LTRIM(RTRIM(T1.SDF_CREDIT_TYPE)) end) AS PROD_CATE_CODE
    , (case when T1.SDF_CREDIT_KIND = ' ' then null else LTRIM(RTRIM(T1.SDF_CREDIT_KIND)) end) AS SUB_CATE_CODE
    ,ltrim(rtrim(T1.FINA_CTRL_CODE)) AS PARAM_ORG_CODE
    ,ltrim(rtrim(T1.FINA_CTRL_CHN_NAME)) AS PARAM_ORG_NAME
    ,ltrim(rtrim(T1.SCDF_PAY_MODE)) AS PAY_MODE
    ,to_date(ltrim(rtrim(T1.SCDF_OPEN_DATE)),'yyyyMMdd') AS OPEN_DATE
    ,to_date(ltrim(rtrim(T1.SCDF_CLOSE_DATE)),'yyyyMMdd') AS CLOSE_DATE
    ,ltrim(rtrim(T1.SRDF_STATUS_FLG)) AS STATUS_FLAG
FROM CEVFINAMSCDRF@COMNEWVIEW T1
/

