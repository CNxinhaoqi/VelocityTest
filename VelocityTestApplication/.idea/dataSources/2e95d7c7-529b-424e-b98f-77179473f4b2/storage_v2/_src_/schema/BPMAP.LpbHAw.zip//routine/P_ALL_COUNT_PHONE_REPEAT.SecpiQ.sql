create procedure P_ALL_COUNT_PHONE_REPEAT(
  CountDate in varchar2
)
as   
BEGIN
  INSERT INTO PHONE_COUNT_3MONTH  
  SELECT a.CUSTOMER_ID , a.MOBILE , count(1),to_date(CountDate,'yyyymmdd')
  FROM (
    SELECT  LA.CUSTOMER_ID , LA.MOBILE
    FROM LOAN_APPLICATION LA
    WHERE (LA.PROC_STATUS NOT IN ('3','4','5')  OR (LA.PROC_STATUS=3 AND PROC_CODE!='APPLY' ))
      AND LA.CREATE_TIME > add_months(sysdate,-3) 
    union all 
    SELECT nvl(LCI.CUSTOMER_ID,LA.CUSTOMER_ID) , LCI.CONTACT_MOBILE
    from LOAN_APPLICATION LA , LOAN_CONTACT_INFO LCI 
    where LA.APPLICATION_NUMBER = LCI.APPLICATION_NUMBER 
      and (LA.PROC_STATUS NOT IN ('3','4','5')  OR (LA.PROC_STATUS=3 AND PROC_CODE!='APPLY' ))
      AND LA.CREATE_TIME > add_months(sysdate,-3)
    ) a
   GROUP BY a.CUSTOMER_ID , a.MOBILE ;
  commit;
  DELETE PHONE_COUNT_3MONTH 
  WHERE to_char(COUNT_DATE,'yyyymmdd') != CountDate;
  commit;

  commit;
END;

/

