create materialized view VIEW_CLEAR_MERCHANT
refresh force on demand
  as
    SELECT 
    (case when T1.FINA_INST_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_INST_CODE)) end) AS MERCHANT_CODE,
    (case when T1.FINA_CHN_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_CHN_NAME)) end) AS MERCHANT_NAME,
    (case when T1.FINA_AREA_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_AREA_CODE)) end) AS AREA_CODE,
    (case when T1.FINA_AREA_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_AREA_NAME)) end) AS AREA_NAME,
    (case when T1.FINA_BOC_AREA_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_BOC_AREA_CODE)) end) AS AREA_CENTER_CODE,
    (case when T1.FINA_BOC_AREA_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_BOC_AREA_NAME)) end) AS AREA_CENTER_NAME,
    (case when T1.FINA_PROVINCE_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_PROVINCE_CODE)) end) AS PROVINCE_CODE,
    (case when T1.FINA_PROVINCE_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_PROVINCE_NAME)) end) AS PROVINCE_NAME,
    (case when T1.FINA_CITY_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_CITY_CODE)) end) AS CITY_CODE,
    (case when T1.FINA_CITY_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_CITY_NAME)) end) AS CITY_NAME,
    (case when T1.FINA_DISTRICT_CODE = ' ' then null else LTRIM(RTRIM(T1.FINA_DISTRICT_CODE)) end) AS DISTRICT_CODE,
    (case when T1.FINA_DISTRICT_NAME = ' ' then null else LTRIM(RTRIM(T1.FINA_DISTRICT_NAME)) end) AS DISTRICT_NAME
FROM CEVFINAPASE@COMNEWVIEW T1
/

