create materialized view VIEW_PROD_RATE
refresh force on demand
  as
    SELECT ltrim(rtrim(T1.SDIV_CRE_LINE_CODE)) AS PROD_CODE
	,ltrim(rtrim(T1.SRIV_CRE_LINE_GROUP)) AS PROD_TYPE
	,ltrim(rtrim(T1.FINA_CTRL_CODE)) AS PARAM_ORG_CODE
	,T1.SDIV_INSTALL_PERIOD AS PERIOD
	,ltrim(rtrim(T1.SDIV_INSTALL_TYPE)) AS INTREST_TYPE
	,ltrim(rtrim(T1.SDIV_GROUP_ID)) AS CUST_GROUP_TYPE
	,ltrim(rtrim(T1.SDIV_STATIC_RATE)) AS STATIC_RATE
	,to_date(ltrim(rtrim(T1.SDIV_OPEN_DATE)),'yyyyMMdd') AS OPEN_DATE
	,to_date(ltrim(rtrim(T1.SDIV_CLOSE_DATE)),'yyyyMMdd') AS CLOSE_DATE
	,ltrim(rtrim(T1.SDIV_STATUS_FLG)) AS STATUS_FLAG
	,ltrim(rtrim(T1.SDIV_REMARK)) AS REMARK
FROM CEVSDRIV@COMNEWVIEW T1
/

