create materialized view VIEW_AREA
refresh force on demand
  as
    SELECT ltrim(rtrim(DIST_COM_CODE)) AS AREA_CODE
	,ltrim(rtrim(DIST_CHN_NAME)) AS AREA_NAME
FROM CEVDIST@COMNEWVIEW
WHERE DIST_TYPE = 1
/

