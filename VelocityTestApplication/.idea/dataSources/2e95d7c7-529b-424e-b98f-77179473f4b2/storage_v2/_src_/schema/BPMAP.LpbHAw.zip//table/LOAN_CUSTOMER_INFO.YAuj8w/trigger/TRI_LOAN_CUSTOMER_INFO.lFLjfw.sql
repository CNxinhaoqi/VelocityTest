create trigger TRI_LOAN_CUSTOMER_INFO
  after update
  on LOAN_CUSTOMER_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.MARRIAGE_CODE is null and :new.MARRIAGE_CODE is not null)
     or (:old.MARRIAGE_CODE is not null and :new.MARRIAGE_CODE is null)
     or (:old.MARRIAGE_CODE <> :new.MARRIAGE_CODE) --婚姻代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'MARRIAGE_CODE'
        ,:old.MARRIAGE_CODE
        ,:new.MARRIAGE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.EMAIL is null and :new.EMAIL is not null)
     or (:old.EMAIL is not null and :new.EMAIL is null)
     or (:old.EMAIL <> :new.EMAIL) --邮箱
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'EMAIL'
        ,:old.EMAIL
        ,:new.EMAIL
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.MOTHER_FAMILY_NAME is null and :new.MOTHER_FAMILY_NAME is not null)
     or (:old.MOTHER_FAMILY_NAME is not null and :new.MOTHER_FAMILY_NAME is null)
     or (:old.MOTHER_FAMILY_NAME <> :new.MOTHER_FAMILY_NAME) --母亲姓氏
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'MOTHER_FAMILY_NAME'
        ,:old.MOTHER_FAMILY_NAME
        ,:new.MOTHER_FAMILY_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.EDUCATION is null and :new.EDUCATION is not null)
     or (:old.EDUCATION is not null and :new.EDUCATION is null)
     or (:old.EDUCATION <> :new.EDUCATION) --教育程度
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'EDUCATION'
        ,:old.EDUCATION
        ,:new.EDUCATION
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.SPO_NAME is null and :new.SPO_NAME is not null)
     or (:old.SPO_NAME is not null and :new.SPO_NAME is null)
     or (:old.SPO_NAME <> :new.SPO_NAME) --配偶姓名
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'SPO_NAME'
        ,:old.SPO_NAME
        ,:new.SPO_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.SPO_MOBILE is null and :new.SPO_MOBILE is not null)
     or (:old.SPO_MOBILE is not null and :new.SPO_MOBILE is null)
     or (:old.SPO_MOBILE <> :new.SPO_MOBILE) --配偶手机号
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'SPO_MOBILE'
        ,:old.SPO_MOBILE
        ,:new.SPO_MOBILE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.SPO_COM_NAME is null and :new.SPO_COM_NAME is not null)
     or (:old.SPO_COM_NAME is not null and :new.SPO_COM_NAME is null)
     or (:old.SPO_COM_NAME <> :new.SPO_COM_NAME) --配偶单位名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CUSTOMER_INFO'
        ,'SPO_COM_NAME'
        ,:old.SPO_COM_NAME
        ,:new.SPO_COM_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
  
END TRI_LOAN_CUSTOMER_INFO;
/

