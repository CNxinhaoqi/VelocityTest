create function oracle_to_unix(in_date IN DATE) return number is

begin

return( (in_date -TO_DATE('19700101','yyyymmdd'))*86400 - TO_NUMBER(SUBSTR(TZ_OFFSET(sessiontimezone),1,3))*3600);

end oracle_to_unix;

/

