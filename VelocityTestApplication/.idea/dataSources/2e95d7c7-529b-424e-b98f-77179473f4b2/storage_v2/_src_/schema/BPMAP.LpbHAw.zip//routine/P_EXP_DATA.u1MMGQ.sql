create procedure p_exp_data
AS
  v_sql varchar2(100);
  cursor c_record IS select DICT_ID from data_dict;
begin
  open c_record;
    loop
      exit when c_record%notfound;
      fetch c_record into v_sql;
      dbms_output.put_line(v_sql);
    end loop;
    exception
      when others then 
        dbms_output.put_line('exception!');
  close c_record;
end;

/

