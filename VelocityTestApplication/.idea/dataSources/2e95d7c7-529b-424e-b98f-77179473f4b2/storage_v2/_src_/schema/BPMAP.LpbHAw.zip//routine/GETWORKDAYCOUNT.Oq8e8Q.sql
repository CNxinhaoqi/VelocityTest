create FUNCTION getWorkDayCount(startDate IN DATE,endDate IN DATE)
RETURN NUMBER
IS
  HOLIDAY_COUNT NUMBER;
  WORK_COUNT NUMBER;
  DATE_CROSS EXCEPTION; --时间交叉
BEGIN
  --======================--
    --startDate YYYYMMDD
    --endDate YYYYMMDD
  --======================--
  SELECT ROUND(TO_NUMBER(endDate - startDate)) INTO WORK_COUNT FROM DUAL;
  IF WORK_COUNT< 0 THEN
    RAISE DATE_CROSS;
  END IF;

  SELECT COUNT(1) INTO HOLIDAY_COUNT FROM VIEW_HOLIDAY WHERE HOLI_DATE > TO_DATE((TO_CHAR(startDate,'yyyyMMdd')||'00000'),'yyyyMMddhh24miss') AND HOLI_DATE < TO_DATE((TO_CHAR(endDate,'yyyyMMdd')||'235959'),'yyyyMMddhh24miss');
  RETURN (WORK_COUNT-HOLIDAY_COUNT);
END getWorkDayCount;
/

