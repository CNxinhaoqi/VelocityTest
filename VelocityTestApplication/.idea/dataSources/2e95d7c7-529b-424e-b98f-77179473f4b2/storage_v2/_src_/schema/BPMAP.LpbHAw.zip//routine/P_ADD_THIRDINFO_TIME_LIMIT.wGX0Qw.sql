create PROCEDURE P_ADD_THIRDINFO_TIME_LIMIT (
	p_prod_code VARCHAR2,
	p_mcht_code VARCHAR2,
	p_info_type VARCHAR2,
	p_limit_start_time TIMESTAMP,
	p_limit_end_time TIMESTAMP
) AS
BEGIN
	-- backup old data to history table
	INSERT INTO THIRDINFO_TIME_LIMIT_HISTORY(
		PROD_CODE,
		MCHT_CODE,
		INFO_TYPE,
		LIMIT_START_TIME,
		LIMIT_END_TIME,
    CREATE_TIME,
    REMOVE_TIME)
  SELECT
    PROD_CODE,
    MCHT_CODE,
    INFO_TYPE,
    LIMIT_START_TIME,
    LIMIT_END_TIME,
    CREATE_TIME,
    SYSDATE
  FROM THIRDINFO_TIME_LIMIT
  WHERE PROD_CODE=p_prod_code
    AND MCHT_CODE=p_mcht_code
    AND INFO_TYPE=p_info_type;

  -- delete old data
  DELETE FROM THIRDINFO_TIME_LIMIT
  WHERE PROD_CODE=p_prod_code
    AND MCHT_CODE=p_mcht_code
    AND INFO_TYPE=p_info_type;

    --insert into new data
  INSERT INTO THIRDINFO_TIME_LIMIT(
    PROD_CODE,
    MCHT_CODE,
    INFO_TYPE,
    LIMIT_START_TIME,
    LIMIT_END_TIME,
    CREATE_TIME)
  VALUES(
    p_prod_code,
    p_mcht_code,
    p_info_type,
    p_limit_start_time,
    p_limit_end_time,
    SYSDATE);
  COMMIT;
END;
/

