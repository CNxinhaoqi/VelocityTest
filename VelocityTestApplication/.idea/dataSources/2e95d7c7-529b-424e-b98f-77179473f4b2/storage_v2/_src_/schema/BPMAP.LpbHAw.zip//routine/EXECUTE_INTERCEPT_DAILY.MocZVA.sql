create PROCEDURE EXECUTE_INTERCEPT_DAILY
IS
 BEGIN
  declare
	 O_STATUS  CHAR;
	 O_RET_MSG  VARCHAR(20);
		BEGIN 
		  P_EXP_INTERCEPT_POINT (to_date(to_char(sysdate-1,'yyyy-MM-dd'),'yyyy-MM-dd'),O_STATUS,O_RET_MSG);
		  dbms_output.put_line('O_STATUS=' || O_STATUS);
		  dbms_output.put_line('O_RET_MSG=' || O_RET_MSG);
  END;
END EXECUTE_INTERCEPT_DAILY;

/

