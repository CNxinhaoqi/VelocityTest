create trigger TRI_LOAN_CREDIT_ADDITION
  after update
  on LOAN_CREDIT_ADDITION
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.COLUMN1 is null and :new.COLUMN1 is not null)
     or (:old.COLUMN1 is not null and :new.COLUMN1 is null)
     or (:old.COLUMN1 <> :new.COLUMN1) --是否二次抵押
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'COLUMN1'
        ,:old.COLUMN1
        ,:new.COLUMN1
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.IS_CHECK_IN is null and :new.IS_CHECK_IN is not null)
     or (:old.IS_CHECK_IN is not null and :new.IS_CHECK_IN is null)
     or (:old.IS_CHECK_IN <> :new.IS_CHECK_IN) --是否已入住
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
		,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'IS_CHECK_IN'
        ,:old.IS_CHECK_IN
        ,:new.IS_CHECK_IN
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.HOUSE_ADDRESS_PROVINCE_CODE is null and :new.HOUSE_ADDRESS_PROVINCE_CODE is not null)
     or (:old.HOUSE_ADDRESS_PROVINCE_CODE is not null and :new.HOUSE_ADDRESS_PROVINCE_CODE is null)
     or (:old.HOUSE_ADDRESS_PROVINCE_CODE <> :new.HOUSE_ADDRESS_PROVINCE_CODE) --房产地址(省)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'HOUSE_ADDRESS_PROVINCE_CODE'
        ,:old.HOUSE_ADDRESS_PROVINCE_CODE
        ,:new.HOUSE_ADDRESS_PROVINCE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.HOUSE_ADDRESS_CITY_CODE is null and :new.HOUSE_ADDRESS_CITY_CODE is not null)
     or (:old.HOUSE_ADDRESS_CITY_CODE is not null and :new.HOUSE_ADDRESS_CITY_CODE is null)
     or (:old.HOUSE_ADDRESS_CITY_CODE <> :new.HOUSE_ADDRESS_CITY_CODE) --房产地址(市)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'HOUSE_ADDRESS_CITY_CODE'
        ,:old.HOUSE_ADDRESS_CITY_CODE
        ,:new.HOUSE_ADDRESS_CITY_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.HOUSE_ADDRESS_AREA_CODE is null and :new.HOUSE_ADDRESS_AREA_CODE is not null)
     or (:old.HOUSE_ADDRESS_AREA_CODE is not null and :new.HOUSE_ADDRESS_AREA_CODE is null)
     or (:old.HOUSE_ADDRESS_AREA_CODE <> :new.HOUSE_ADDRESS_AREA_CODE) --房产地址(区县)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'HOUSE_ADDRESS_AREA_CODE'
        ,:old.HOUSE_ADDRESS_AREA_CODE
        ,:new.HOUSE_ADDRESS_AREA_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.HOUSE_ADDRESS is null and :new.HOUSE_ADDRESS is not null)
     or (:old.HOUSE_ADDRESS is not null and :new.HOUSE_ADDRESS is null)
     or (:old.HOUSE_ADDRESS <> :new.HOUSE_ADDRESS) --房产地址
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'HOUSE_ADDRESS'
        ,:old.HOUSE_ADDRESS
        ,:new.HOUSE_ADDRESS
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  IF (:old.IS_BOC_USER is null and :new.IS_BOC_USER is not null)
     or (:old.IS_BOC_USER is not null and :new.IS_BOC_USER is null)
     or (:old.IS_BOC_USER <> :new.IS_BOC_USER) --是否中行客户
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'IS_BOC_USER'
        ,:old.IS_BOC_USER
        ,:new.IS_BOC_USER
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.RECEIPT_NO is null and :new.RECEIPT_NO is not null)
     or (:old.RECEIPT_NO is not null and :new.RECEIPT_NO is null)
     or (:old.RECEIPT_NO <> :new.RECEIPT_NO) --收件收据编号
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'RECEIPT_NO'
        ,:old.RECEIPT_NO
        ,:new.RECEIPT_NO
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.OTHER_RIGHTS_NO is null and :new.OTHER_RIGHTS_NO is not null)
     or (:old.OTHER_RIGHTS_NO is not null and :new.OTHER_RIGHTS_NO is null)
     or (:old.OTHER_RIGHTS_NO <> :new.OTHER_RIGHTS_NO) --他证编号
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'OTHER_RIGHTS_NO'
        ,:old.OTHER_RIGHTS_NO
        ,:new.OTHER_RIGHTS_NO
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLUMN2 is null and :new.COLUMN2 is not null)
     or (:old.COLUMN2 is not null and :new.COLUMN2 is null)
     or (:old.COLUMN2 <> :new.COLUMN2) --是否提供连续缴纳6个月（含）以上缴金证明材料
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'COLUMN2'
        ,:old.COLUMN2
        ,:new.COLUMN2
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_WORK_ADDR_FLAG is null and :new.HOUSE_WORK_ADDR_FLAG is not null)
     or (:old.HOUSE_WORK_ADDR_FLAG is not null and :new.HOUSE_WORK_ADDR_FLAG is null)
     or (:old.HOUSE_WORK_ADDR_FLAG <> :new.HOUSE_WORK_ADDR_FLAG) --工作生活地址与房产地址是否不一致
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      )
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CREDIT_ADDITION'
        ,'HOUSE_WORK_ADDR_FLAG'
        ,:old.HOUSE_WORK_ADDR_FLAG
        ,:new.HOUSE_WORK_ADDR_FLAG
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_CREDIT_ADDITION;
/

