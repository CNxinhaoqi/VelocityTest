create trigger TRI_LOAN_INCOME_INFO
  after update
  on LOAN_INCOME_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.INCOME_CUR_MON is null and :new.INCOME_CUR_MON is not null)
     or (:old.INCOME_CUR_MON is not null and :new.INCOME_CUR_MON is null)
     or (:old.INCOME_CUR_MON <> :new.INCOME_CUR_MON) --当前月收入
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_INCOME_INFO'
        ,'INCOME_CUR_MON'
        ,:old.INCOME_CUR_MON
        ,:new.INCOME_CUR_MON
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_INCOME_INFO;
/

