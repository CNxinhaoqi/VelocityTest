create trigger TRI_LOAN_CONTACT_INFO
  after insert
  on LOAN_CONTACT_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :new.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF :new.CONTACT_IDNO is not null --联系人身份证号
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_IDNO'
        ,:new.CONTACT_IDNO
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_NAME is not null --联系人姓名
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_NAME'
        ,:new.CONTACT_NAME
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_RELATION is not null --联系人与本人（客户）关系代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_RELATION'
        ,:new.CONTACT_RELATION
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_ADDRESS_PROVINCE_CODE is not null --联系人地址(省)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_PROVINCE_CODE'
        ,:new.CONTACT_ADDRESS_PROVINCE_CODE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_ADDRESS_CITY_CODE is not null --联系人地址(市) 代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_CITY_CODE'
        ,:new.CONTACT_ADDRESS_CITY_CODE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_ADDRESS_AREA_CODE is not null --联系人地址(区县) 代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_AREA_CODE'
        ,:new.CONTACT_ADDRESS_AREA_CODE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_ADDRESS is not null --联系人地址(详细)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS'
        ,:new.CONTACT_ADDRESS
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_ADDRESS_ZIPCODE is not null --联系人地址(邮编)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_ADDRESS_ZIPCODE'
        ,:new.CONTACT_ADDRESS_ZIPCODE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_MOBILE is not null --联系人手机号码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_MOBILE'
        ,:new.CONTACT_MOBILE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_TEL_AREACODE is not null --联系人电话(区号)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL_AREACODE'
        ,:new.CONTACT_TEL_AREACODE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_TEL is not null --联系人电话
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL'
        ,:new.CONTACT_TEL
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_TEL_EXT is not null --联系人电话(分机号码)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_TEL_EXT'
        ,:new.CONTACT_TEL_EXT
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_NOTE is not null --联系人备注
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_NOTE'
        ,:new.CONTACT_NOTE
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF :new.CONTACT_COM_NAME is not null --联系人公司名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :new.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_CONTACT_INFO'
        ,'CONTACT_COM_NAME'
        ,:new.CONTACT_COM_NAME
        ,:new.CREATE_USER
        ,:new.CREATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_CONTACT_INFO;
/

