create trigger TRI_LOAN_WORK_INFO
  after update
  on LOAN_WORK_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.COM_NAME is null and :new.COM_NAME is not null)
     or (:old.COM_NAME is not null and :new.COM_NAME is null)
     or (:old.COM_NAME <> :new.COM_NAME) --单位名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COM_NAME'
        ,:old.COM_NAME
        ,:new.COM_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.DEPARTMENT is null and :new.DEPARTMENT is not null)
     or (:old.DEPARTMENT is not null and :new.DEPARTMENT is null)
     or (:old.DEPARTMENT <> :new.DEPARTMENT) --部门名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'DEPARTMENT'
       ,:old.DEPARTMENT
        ,:new.DEPARTMENT
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.POSITION_NAME is null and :new.POSITION_NAME is not null)
     or (:old.POSITION_NAME is not null and :new.POSITION_NAME is null)
     or (:old.POSITION_NAME <> :new.POSITION_NAME) --职务名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'POSITION_NAME'
        ,:old.POSITION_NAME
        ,:new.POSITION_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.POSITION_CODE is null and :new.POSITION_CODE is not null)
     or (:old.POSITION_CODE is not null and :new.POSITION_CODE is null)
     or (:old.POSITION_CODE <> :new.POSITION_CODE) --职位代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'POSITION_CODE'
        ,:old.POSITION_CODE
        ,:new.POSITION_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_ADDRESS_PROVINCE_CODE is null and :new.COMPANY_ADDRESS_PROVINCE_CODE is not null)
     or (:old.COMPANY_ADDRESS_PROVINCE_CODE is not null and :new.COMPANY_ADDRESS_PROVINCE_CODE is null)
     or (:old.COMPANY_ADDRESS_PROVINCE_CODE <> :new.COMPANY_ADDRESS_PROVINCE_CODE) --单位地址(省)��码

    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_ADDRESS_PROVINCE_CODE'
        ,:old.COMPANY_ADDRESS_PROVINCE_CODE
        ,:new.COMPANY_ADDRESS_PROVINCE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_ADDRESS_CITY_CODE is null and :new.COMPANY_ADDRESS_CITY_CODE is not null)
     or (:old.COMPANY_ADDRESS_CITY_CODE is not null and :new.COMPANY_ADDRESS_CITY_CODE is null)
     or (:old.COMPANY_ADDRESS_CITY_CODE <> :new.COMPANY_ADDRESS_CITY_CODE) --单位地址(市)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_ADDRESS_CITY_CODE'
        ,:old.COMPANY_ADDRESS_CITY_CODE
        ,:new.COMPANY_ADDRESS_CITY_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_ADDRESS_AREA_CODE is null and :new.COMPANY_ADDRESS_AREA_CODE is not null)
     or (:old.COMPANY_ADDRESS_AREA_CODE is not null and :new.COMPANY_ADDRESS_AREA_CODE is null)
     or (:old.COMPANY_ADDRESS_AREA_CODE <> :new.COMPANY_ADDRESS_AREA_CODE) --单位地址(区县)代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_ADDRESS_AREA_CODE'
        ,:old.COMPANY_ADDRESS_AREA_CODE
        ,:new.COMPANY_ADDRESS_AREA_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_ADDRESS is null and :new.COMPANY_ADDRESS is not null)
     or (:old.COMPANY_ADDRESS is not null and :new.COMPANY_ADDRESS is null)
     or (:old.COMPANY_ADDRESS <> :new.COMPANY_ADDRESS) --单位地址(详细)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_ADDRESS'
        ,:old.COMPANY_ADDRESS
        ,:new.COMPANY_ADDRESS
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.OCCUPATION is null and :new.OCCUPATION is not null)
     or (:old.OCCUPATION is not null and :new.OCCUPATION is null)
     or (:old.OCCUPATION <> :new.OCCUPATION) --职业
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'OCCUPATION'
        ,:old.OCCUPATION
        ,:new.OCCUPATION
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_ADDRESS_ZIPCODE is null and :new.COMPANY_ADDRESS_ZIPCODE is not null)
     or (:old.COMPANY_ADDRESS_ZIPCODE is not null and :new.COMPANY_ADDRESS_ZIPCODE is null)
     or (:old.COMPANY_ADDRESS_ZIPCODE <> :new.COMPANY_ADDRESS_ZIPCODE) --单位地址邮编
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_ADDRESS_ZIPCODE'
        ,:old.COMPANY_ADDRESS_ZIPCODE
        ,:new.COMPANY_ADDRESS_ZIPCODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_TEL_AREACODE is null and :new.COMPANY_TEL_AREACODE is not null)
     or (:old.COMPANY_TEL_AREACODE is not null and :new.COMPANY_TEL_AREACODE is null)
     or (:old.COMPANY_TEL_AREACODE <> :new.COMPANY_TEL_AREACODE) --单位电话(区号)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_TEL_AREACODE'
        ,:old.COMPANY_TEL_AREACODE
        ,:new.COMPANY_TEL_AREACODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_TEL is null and :new.COMPANY_TEL is not null)
     or (:old.COMPANY_TEL is not null and :new.COMPANY_TEL is null)
     or (:old.COMPANY_TEL <> :new.COMPANY_TEL) --单位电话
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_TEL'
        ,:old.COMPANY_TEL
        ,:new.COMPANY_TEL
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.COMPANY_TEL_EXT is null and :new.COMPANY_TEL_EXT is not null)
     or (:old.COMPANY_TEL_EXT is not null and :new.COMPANY_TEL_EXT is null)
     or (:old.COMPANY_TEL_EXT <> :new.COMPANY_TEL_EXT) --单位电话(分机号码)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'COMPANY_TEL_EXT'
        ,:old.COMPANY_TEL_EXT
        ,:new.COMPANY_TEL_EXT
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.EMPLOYED_YEAR is null and :new.EMPLOYED_YEAR is not null)
     or (:old.EMPLOYED_YEAR is not null and :new.EMPLOYED_YEAR is null)
     or (:old.EMPLOYED_YEAR <> :new.EMPLOYED_YEAR) --现单位入职时间(年)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'EMPLOYED_YEAR'
        ,:old.EMPLOYED_YEAR
        ,:new.EMPLOYED_YEAR
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.EMPLOYED_MONTH is null and :new.EMPLOYED_MONTH is not null)
     or (:old.EMPLOYED_MONTH is not null and :new.EMPLOYED_MONTH is null)
     or (:old.EMPLOYED_MONTH <> :new.EMPLOYED_MONTH) --现单位入职时间(月)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'EMPLOYED_MONTH'
        ,:old.EMPLOYED_MONTH
        ,:new.EMPLOYED_MONTH
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.WORK_EXP is null and :new.WORK_EXP is not null)
     or (:old.WORK_EXP is not null and :new.WORK_EXP is null)
     or (:old.WORK_EXP <> :new.WORK_EXP) --工作年限(年)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'WORK_EXP'
        ,:old.WORK_EXP
        ,:new.WORK_EXP
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.WORK_EXP_MON is null and :new.WORK_EXP_MON is not null)
     or (:old.WORK_EXP_MON is not null and :new.WORK_EXP_MON is null)
     or (:old.WORK_EXP_MON <> :new.WORK_EXP_MON) --工作年限(月)
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'WORK_EXP_MON'
        ,:old.WORK_EXP_MON
        ,:new.WORK_EXP_MON
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IND_NATURE is null and :new.IND_NATURE is not null)
     or (:old.IND_NATURE is not null and :new.IND_NATURE is null)
     or (:old.IND_NATURE <> :new.IND_NATURE) --行业性质代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'IND_NATURE'
        ,:old.IND_NATURE
        ,:new.IND_NATURE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IND_NATURE_NAME is null and :new.IND_NATURE_NAME is not null)
     or (:old.IND_NATURE_NAME is not null and :new.IND_NATURE_NAME is null)
     or (:old.IND_NATURE_NAME <> :new.IND_NATURE_NAME) --行业性质名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'IND_NATURE_NAME'
        ,:old.IND_NATURE_NAME
        ,:new.IND_NATURE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.ENTERPRISE_NATURE_CODE is null and :new.ENTERPRISE_NATURE_CODE is not null)
     or (:old.ENTERPRISE_NATURE_CODE is not null and :new.ENTERPRISE_NATURE_CODE is null)
     or (:old.ENTERPRISE_NATURE_CODE <> :new.ENTERPRISE_NATURE_CODE) --企业性质代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'ENTERPRISE_NATURE_CODE'
        ,:old.ENTERPRISE_NATURE_CODE
        ,:new.ENTERPRISE_NATURE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.ENTERPRISE_NATURE_NAME is null and :new.ENTERPRISE_NATURE_NAME is not null)
     or (:old.ENTERPRISE_NATURE_NAME is not null and :new.ENTERPRISE_NATURE_NAME is null)
     or (:old.ENTERPRISE_NATURE_NAME <> :new.ENTERPRISE_NATURE_NAME) --企业性质名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'ENTERPRISE_NATURE_NAME'
        ,:old.ENTERPRISE_NATURE_NAME
        ,:new.ENTERPRISE_NATURE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.ECO_TYPE is null and :new.ECO_TYPE is not null)
     or (:old.ECO_TYPE is not null and :new.ECO_TYPE is null)
     or (:old.ECO_TYPE <> :new.ECO_TYPE) --经济类型代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'ECO_TYPE'
        ,:old.ECO_TYPE
        ,:new.ECO_TYPE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.ECO_TYPE_NAME is null and :new.ECO_TYPE_NAME is not null)
     or (:old.ECO_TYPE_NAME is not null and :new.ECO_TYPE_NAME is null)
     or (:old.ECO_TYPE_NAME <> :new.ECO_TYPE_NAME) --经济类型名称
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'ECO_TYPE_NAME'
        ,:old.ECO_TYPE_NAME
        ,:new.ECO_TYPE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.PROFESSION is null and :new.PROFESSION is not null)
     or (:old.PROFESSION is not null and :new.PROFESSION is null)
     or (:old.PROFESSION <> :new.PROFESSION) --职务
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_WORK_INFO'
        ,'PROFESSION'
        ,:old.PROFESSION
        ,:new.PROFESSION
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_WORK_INFO;
/

