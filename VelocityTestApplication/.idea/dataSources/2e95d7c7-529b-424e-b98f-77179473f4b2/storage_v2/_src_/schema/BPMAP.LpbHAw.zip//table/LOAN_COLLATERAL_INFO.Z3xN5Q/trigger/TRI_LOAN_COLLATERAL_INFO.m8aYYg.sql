create trigger TRI_LOAN_COLLATERAL_INFO
  after update
  on LOAN_COLLATERAL_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.COLLATERAL_HOUSE_TYPE_NAME is null and :new.COLLATERAL_HOUSE_TYPE_NAME is not null)
     or (:old.COLLATERAL_HOUSE_TYPE_NAME is not null and :new.COLLATERAL_HOUSE_TYPE_NAME is null)
     or (:old.COLLATERAL_HOUSE_TYPE_NAME <> :new.COLLATERAL_HOUSE_TYPE_NAME) --抵押物类型
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_HOUSE_TYPE_NAME'
        ,:old.COLLATERAL_HOUSE_TYPE_NAME
        ,:new.COLLATERAL_HOUSE_TYPE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_EVS is null and :new.COLLATERAL_EVS is not null)
     or (:old.COLLATERAL_EVS is not null and :new.COLLATERAL_EVS is null)
     or (:old.COLLATERAL_EVS <> :new.COLLATERAL_EVS) --抵押物价值
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_EVS'
        ,:old.COLLATERAL_EVS
        ,:new.COLLATERAL_EVS
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_PROVINCE_CODE is null and :new.COLLATERAL_ADDR_PROVINCE_CODE is not null)
     or (:old.COLLATERAL_ADDR_PROVINCE_CODE is not null and :new.COLLATERAL_ADDR_PROVINCE_CODE is null)
     or (:old.COLLATERAL_ADDR_PROVINCE_CODE <> :new.COLLATERAL_ADDR_PROVINCE_CODE) --省
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_PROVINCE_CODE'
        ,:old.COLLATERAL_ADDR_PROVINCE_CODE
        ,:new.COLLATERAL_ADDR_PROVINCE_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_CITY_CODE is null and :new.COLLATERAL_ADDR_CITY_CODE is not null)
     or (:old.COLLATERAL_ADDR_CITY_CODE is not null and :new.COLLATERAL_ADDR_CITY_CODE is null)
     or (:old.COLLATERAL_ADDR_CITY_CODE <> :new.COLLATERAL_ADDR_CITY_CODE) --抵押物市
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_CITY_CODE'
        ,:old.COLLATERAL_ADDR_CITY_CODE
        ,:new.COLLATERAL_ADDR_CITY_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_AREA_CODE is null and :new.COLLATERAL_ADDR_AREA_CODE is not null)
     or (:old.COLLATERAL_ADDR_AREA_CODE is not null and :new.COLLATERAL_ADDR_AREA_CODE is null)
     or (:old.COLLATERAL_ADDR_AREA_CODE <> :new.COLLATERAL_ADDR_AREA_CODE) --抵押物区
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_AREA_CODE'
        ,:old.COLLATERAL_ADDR_AREA_CODE
        ,:new.COLLATERAL_ADDR_AREA_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_CNTR_PROV is null and :new.COLLATERAL_ADDR_CNTR_PROV is not null)
     or (:old.COLLATERAL_ADDR_CNTR_PROV is not null and :new.COLLATERAL_ADDR_CNTR_PROV is null)
     or (:old.COLLATERAL_ADDR_CNTR_PROV <> :new.COLLATERAL_ADDR_CNTR_PROV) --省
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_CNTR_PROV'
        ,:old.COLLATERAL_ADDR_CNTR_PROV
        ,:new.COLLATERAL_ADDR_CNTR_PROV
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_CNTR_CITY is null and :new.COLLATERAL_ADDR_CNTR_CITY is not null)
     or (:old.COLLATERAL_ADDR_CNTR_CITY is not null and :new.COLLATERAL_ADDR_CNTR_CITY is null)
     or (:old.COLLATERAL_ADDR_CNTR_CITY <> :new.COLLATERAL_ADDR_CNTR_CITY) --抵押物市
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_CNTR_CITY'
        ,:old.COLLATERAL_ADDR_CNTR_CITY
        ,:new.COLLATERAL_ADDR_CNTR_CITY
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDR_CNTR_AREA is null and :new.COLLATERAL_ADDR_CNTR_AREA is not null)
     or (:old.COLLATERAL_ADDR_CNTR_AREA is not null and :new.COLLATERAL_ADDR_CNTR_AREA is null)
     or (:old.COLLATERAL_ADDR_CNTR_AREA <> :new.COLLATERAL_ADDR_CNTR_AREA) --抵押物区
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDR_CNTR_AREA'
        ,:old.COLLATERAL_ADDR_CNTR_AREA
        ,:new.COLLATERAL_ADDR_CNTR_AREA
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.COLLATERAL_ADDRESS is null and :new.COLLATERAL_ADDRESS is not null)
     or (:old.COLLATERAL_ADDRESS is not null and :new.COLLATERAL_ADDRESS is null)
     or (:old.COLLATERAL_ADDRESS <> :new.COLLATERAL_ADDRESS) --抵押物街道
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'COLLATERAL_ADDRESS'
        ,:old.COLLATERAL_ADDRESS
        ,:new.COLLATERAL_ADDRESS
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.CAR_TYPE_NAME is null and :new.CAR_TYPE_NAME is not null)
     or (:old.CAR_TYPE_NAME is not null and :new.CAR_TYPE_NAME is null)
     or (:old.CAR_TYPE_NAME <> :new.CAR_TYPE_NAME) --抵押物所属人
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_COLLATERAL_INFO'
        ,'CAR_TYPE_NAME'
        ,:old.CAR_TYPE_NAME
        ,:new.CAR_TYPE_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_COLLATERAL_INFO;
/

