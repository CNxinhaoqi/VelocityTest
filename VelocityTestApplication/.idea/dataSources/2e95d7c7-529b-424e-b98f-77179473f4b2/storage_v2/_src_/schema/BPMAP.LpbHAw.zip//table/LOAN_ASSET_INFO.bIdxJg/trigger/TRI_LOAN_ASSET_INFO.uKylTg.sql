create trigger TRI_LOAN_ASSET_INFO
  after update of HOUSE_LOAN_BANK_CODE, IS_FORWARD_DELIVERY_HOUSE, HOUSE_MARKET_VALUES, HOUSE_FINISH_DATE, HOUSE_SQUARE, PBC_LOAN_RELEASE_DATE, PBC_LOAN_AMT, HOUSE_SHARE_COUNT, HOUSE_LOAN_BALANCE, HOUSE_EVALUATE_TYPE, SPO_SHARE_PROPORTION, IS_LIMIT_CLOSE_INFO, IS_OTHER_HOUSE_NET_VALUES, SUPPLY_HOUSE_NET_VALUES
  on LOAN_ASSET_INFO
  for each row
  DECLARE
  PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_CODE VARCHAR(1000);
  LAST_SPECIAL_PROC_TYPE VARCHAR(1000);
  temp_count NUMBER(10, 0);
BEGIN
  select t.PROC_CODE,t.LAST_SPECIAL_PROC_CODE,t.LAST_SPECIAL_PROC_TYPE into PROC_CODE,LAST_SPECIAL_PROC_CODE,LAST_SPECIAL_PROC_TYPE 
  from LOAN_APPLICATION t where t.APPLICATION_NUMBER = :old.APPLICATION_NUMBER;
  IF (PROC_CODE = 'GIMGUPCHK' or PROC_CODE = 'GRISKOFF') and (LAST_SPECIAL_PROC_CODE = 'GDATAVERF' or LAST_SPECIAL_PROC_CODE = 'GFRMIMCHK') and LAST_SPECIAL_PROC_TYPE = 11
  then
    temp_count := 0;
    IF (:old.HOUSE_SHARE_COUNT is null and :new.HOUSE_SHARE_COUNT is not null)
     or (:old.HOUSE_SHARE_COUNT is not null and :new.HOUSE_SHARE_COUNT is null)
     or (:old.HOUSE_SHARE_COUNT <> :new.HOUSE_SHARE_COUNT) --房产权利人数
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_SHARE_COUNT'
        ,:old.HOUSE_SHARE_COUNT
        ,:new.HOUSE_SHARE_COUNT
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.SPO_SHARE_PROPORTION is null and :new.SPO_SHARE_PROPORTION is not null)
     or (:old.SPO_SHARE_PROPORTION is not null and :new.SPO_SHARE_PROPORTION is null)
     or (:old.SPO_SHARE_PROPORTION <> :new.SPO_SHARE_PROPORTION) --主贷人份额占比
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'SPO_SHARE_PROPORTION'
        ,:old.SPO_SHARE_PROPORTION
        ,:new.SPO_SHARE_PROPORTION
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_LOAN_BANK_CODE is null and :new.HOUSE_LOAN_BANK_CODE is not null)
     or (:old.HOUSE_LOAN_BANK_CODE is not null and :new.HOUSE_LOAN_BANK_CODE is null)
     or (:old.HOUSE_LOAN_BANK_CODE <> :new.HOUSE_LOAN_BANK_CODE) --房贷所属行代码
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_LOAN_BANK_CODE'
        ,:old.HOUSE_LOAN_BANK_CODE
        ,:new.HOUSE_LOAN_BANK_CODE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IS_LIMIT_CLOSE_INFO is null and :new.IS_LIMIT_CLOSE_INFO is not null)
     or (:old.IS_LIMIT_CLOSE_INFO is not null and :new.IS_LIMIT_CLOSE_INFO is null)
     or (:old.IS_LIMIT_CLOSE_INFO <> :new.IS_LIMIT_CLOSE_INFO) --是否有限制、查封信息
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'IS_LIMIT_CLOSE_INFO'
        ,:old.IS_LIMIT_CLOSE_INFO
        ,:new.IS_LIMIT_CLOSE_INFO
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_FINISH_DATE is null and :new.HOUSE_FINISH_DATE is not null)
     or (:old.HOUSE_FINISH_DATE is not null and :new.HOUSE_FINISH_DATE is null)
     or (:old.HOUSE_FINISH_DATE <> :new.HOUSE_FINISH_DATE) --房产确权竣工日期
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_FINISH_DATE'
        ,:old.HOUSE_FINISH_DATE
        ,:new.HOUSE_FINISH_DATE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IS_FORWARD_DELIVERY_HOUSE is null and :new.IS_FORWARD_DELIVERY_HOUSE is not null)
     or (:old.IS_FORWARD_DELIVERY_HOUSE is not null and :new.IS_FORWARD_DELIVERY_HOUSE is null)
     or (:old.IS_FORWARD_DELIVERY_HOUSE <> :new.IS_FORWARD_DELIVERY_HOUSE) --房产是否期房
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'IS_FORWARD_DELIVERY_HOUSE'
        ,:old.IS_FORWARD_DELIVERY_HOUSE
        ,:new.IS_FORWARD_DELIVERY_HOUSE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_EVALUATE_TYPE is null and :new.HOUSE_EVALUATE_TYPE is not null)
     or (:old.HOUSE_EVALUATE_TYPE is not null and :new.HOUSE_EVALUATE_TYPE is null)
     or (:old.HOUSE_EVALUATE_TYPE <> :new.HOUSE_EVALUATE_TYPE) --房产预估类型
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_EVALUATE_TYPE'
        ,:old.HOUSE_EVALUATE_TYPE
        ,:new.HOUSE_EVALUATE_TYPE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_SQUARE is null and :new.HOUSE_SQUARE is not null)
     or (:old.HOUSE_SQUARE is not null and :new.HOUSE_SQUARE is null)
     or (:old.HOUSE_SQUARE <> :new.HOUSE_SQUARE) --房产确权面积
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_SQUARE'
        ,:old.HOUSE_SQUARE
        ,:new.HOUSE_SQUARE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_MARKET_VALUES is null and :new.HOUSE_MARKET_VALUES is not null)
     or (:old.HOUSE_MARKET_VALUES is not null and :new.HOUSE_MARKET_VALUES is null)
     or (:old.HOUSE_MARKET_VALUES <> :new.HOUSE_MARKET_VALUES) --房产市值
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_MARKET_VALUES'
        ,:old.HOUSE_MARKET_VALUES
        ,:new.HOUSE_MARKET_VALUES
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.IS_OTHER_HOUSE_NET_VALUES is null and :new.IS_OTHER_HOUSE_NET_VALUES is not null)
     or (:old.IS_OTHER_HOUSE_NET_VALUES is not null and :new.IS_OTHER_HOUSE_NET_VALUES is null)
     or (:old.IS_OTHER_HOUSE_NET_VALUES <> :new.IS_OTHER_HOUSE_NET_VALUES) --是否有其他房产净值补充
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'IS_OTHER_HOUSE_NET_VALUES'
        ,:old.IS_OTHER_HOUSE_NET_VALUES
        ,:new.IS_OTHER_HOUSE_NET_VALUES
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.SUPPLY_HOUSE_NET_VALUES is null and :new.SUPPLY_HOUSE_NET_VALUES is not null)
     or (:old.SUPPLY_HOUSE_NET_VALUES is not null and :new.SUPPLY_HOUSE_NET_VALUES is null)
     or (:old.SUPPLY_HOUSE_NET_VALUES <> :new.SUPPLY_HOUSE_NET_VALUES) --补充房产净值
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'SUPPLY_HOUSE_NET_VALUES'
        ,:old.SUPPLY_HOUSE_NET_VALUES
        ,:new.SUPPLY_HOUSE_NET_VALUES
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.PBC_LOAN_AMT is null and :new.PBC_LOAN_AMT is not null)
     or (:old.PBC_LOAN_AMT is not null and :new.PBC_LOAN_AMT is null)
     or (:old.PBC_LOAN_AMT <> :new.PBC_LOAN_AMT) --人行原贷款发放金额
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'PBC_LOAN_AMT'
        ,:old.PBC_LOAN_AMT
        ,:new.PBC_LOAN_AMT
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.PBC_LOAN_RELEASE_DATE is null and :new.PBC_LOAN_RELEASE_DATE is not null)
     or (:old.PBC_LOAN_RELEASE_DATE is not null and :new.PBC_LOAN_RELEASE_DATE is null)
     or (:old.PBC_LOAN_RELEASE_DATE <> :new.PBC_LOAN_RELEASE_DATE) --人行原贷款发放日期
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'PBC_LOAN_RELEASE_DATE'
        ,:old.PBC_LOAN_RELEASE_DATE
        ,:new.PBC_LOAN_RELEASE_DATE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
	IF (:old.HOUSE_LOAN_BALANCE is null and :new.HOUSE_LOAN_BALANCE is not null)
     or (:old.HOUSE_LOAN_BALANCE is not null and :new.HOUSE_LOAN_BALANCE is null)
     or (:old.HOUSE_LOAN_BALANCE <> :new.HOUSE_LOAN_BALANCE)--房屋所剩贷款余额
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_LOAN_BALANCE'
        ,:old.HOUSE_LOAN_BALANCE
        ,:new.HOUSE_LOAN_BALANCE
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
    IF (:old.HOUSE_LOAN_BANK_NAME is null and :new.HOUSE_LOAN_BANK_NAME is not null)
     or (:old.HOUSE_LOAN_BANK_NAME is not null and :new.HOUSE_LOAN_BANK_NAME is null)
     or (:old.HOUSE_LOAN_BANK_NAME <> :new.HOUSE_LOAN_BANK_NAME)--放贷所属银行
    THEN
      temp_count := temp_count + 1;
      Insert into DATA_UPDATE_RECORD 
      (
        APPLICATION_NUMBER,
        PROC_CODE,
        TABLE_NAME,
        COLUMN_NAME,
        BEFORE_VALUE,
        AFTER_VALUE,
        USER_CODE,
        USER_NAME,
        SEQ_NUM,
        CREATE_TIME
      ) 
      values (
        :old.APPLICATION_NUMBER
        ,PROC_CODE
        ,'LOAN_ASSET_INFO'
        ,'HOUSE_LOAN_BANK_NAME'
        ,:old.HOUSE_LOAN_BANK_NAME
        ,:new.HOUSE_LOAN_BANK_NAME
        ,:new.UPDATE_USER
        ,:new.UPDATE_USER_NAME
        ,temp_count
        ,sysdate
      );
    END IF;
  END IF;
END TRI_LOAN_ASSET_INFO;
/

