create materialized view VIEW_PRODUCT_RATE_DIFF
refresh force on demand
  as
    SELECT ltrim(rtrim(T1.DIFF_CRE_LINE_CODE)) AS PROD_CODE
    ,ltrim(rtrim(T1.DIFF_INST_CODE)) AS PARAM_ORG_CODE
    ,ltrim(rtrim(T1.DIFF_TYPE)) AS BLUEPRINT
    ,ltrim(rtrim(T1.DIFF_GROUP_ID)) AS CUST_GROUP_TYPE
    ,T1.DIFF_INSTALL_PERIOD AS PERIOD
    ,ltrim(rtrim(T1.DIFF_RATE_TYPE)) AS INTREST_TYPE
    ,ltrim(rtrim(T1.DIFF_RATE)) AS STATIC_RATE
    ,to_date(ltrim(rtrim(T1.DIFF_OPEN_DATE)),'yyyyMMdd') AS OPEN_DATE
    ,to_date(ltrim(rtrim(T1.DIFF_CLOSE_DATE)),'yyyyMMdd') AS CLOSE_DATE
FROM CEVNASDIFF@COMNEWVIEW T1
/

