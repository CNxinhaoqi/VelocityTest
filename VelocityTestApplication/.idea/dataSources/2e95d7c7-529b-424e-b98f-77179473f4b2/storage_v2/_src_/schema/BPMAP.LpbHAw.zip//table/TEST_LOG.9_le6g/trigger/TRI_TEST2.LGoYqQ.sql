create trigger TRI_TEST2
  after update
  on TEST_LOG
  for each row
  DECLARE
age NUMBER;
sex NUMBER;
BEGIN
  select T_AGE,T_SEX INTO age,sex from TEST_CS where T_ID = 1;
  if age = 20 and sex = 1
  then
    update TEST_CS set T_NAME = 1;
  end if;
  
END TRI_TEST2;
/

